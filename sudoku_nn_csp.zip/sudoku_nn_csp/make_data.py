import argparse
import json

from sudoku_rs import config as C
from sudoku_rs import data


def main():
    C.safe_console()
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=C.MASTER_SEED)
    args = ap.parse_args()
    print("1/2 downloading + verifying MNIST ...")
    sums = data.download_all()
    print("2/2 preprocessing (scale, 50k/10k split, drop digit 0) ...")
    manifest = data.preprocess(seed=args.seed)
    manifest["md5"] = sums
    (C.DATA_PROC / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({k: manifest[k] for k in ("seed", "sizes_after_dropping_zero",
                                               "min_pixels_above_0.5_in_any_digit_image")}, indent=2))
    print("done ->", C.DATA_PROC / data.PROCESSED_FILE)


if __name__ == "__main__":
    main()
