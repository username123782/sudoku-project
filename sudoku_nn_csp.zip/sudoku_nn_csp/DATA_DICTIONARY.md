# Data dictionary

**Real vs generated.** Digit images and digit labels are **real** (MNIST). Everything about the Sudoku puzzles,
the 9x9 mosaics, the blank-cell noise and the choice of which digits are "hard" is **generated** by the seeded
rules below. This is *not* photographed real-world Sudoku (as required by the project brief).

## 1. Raw data (real) - `data/raw/`
| file | content | check |
|---|---|---|
| `train-images-idx3-ubyte.gz` | 60,000 images 28x28, uint8 0-255 | MD5 `f68b3c2dcbeaaa9fbdd348bbdeb94873` |
| `train-labels-idx1-ubyte.gz` | 60,000 digit labels 0-9 | MD5 `d53e105ee54ea40749a09fcbcd1e9432` |
| `t10k-images-idx3-ubyte.gz` | 10,000 test images (different writers) | MD5 `9fb629c4189551a2d022fa330f9573f3` |
| `t10k-labels-idx1-ubyte.gz` | 10,000 test labels | MD5 `ec29112dd5afa0611ce80d1b7f02629c` |

Source: Y. LeCun's MNIST page; `make_data.py` tries three mirrors and verifies every file against the official
MD5, so the mirror used does not matter. MNIST is freely available for research and coursework.

## 2. Processed data (real) - `data/processed/mnist_1to9.npz` (made by `make_data.py`, seed 2026)
| array | shape | dtype | meaning |
|---|---|---|---|
| `X_train` / `X_val` / `X_test` | (45069, 784) / (9008, 784) / (9020, 784) | uint8 (scaled to 0-1 on load) | flattened 28x28 digit images |
| `d_train` / `d_val` / `d_test` | same N | uint8 | digit 1-9 (class label for the network = digit - 1) |

* Split: seeded permutation of the 60,000 training images -> 50,000 train / 10,000 validation; the 10,000 official
  test images are untouched. Digit **0 is dropped** everywhere (Sudoku has no 0), which leaves the sizes above.
* `manifest.json` holds seed, sizes, per-digit counts, MD5 sums and the blank-rule check.
* **Blank-cell rule (not the network):** a cell is blank iff fewer than 10 of its 784 pixels exceed 0.5.
  Every digit image has >= 15 such pixels; noise cells have 0 (verified in `tests/test_pipeline.py`).

## 3. Generated data
### 3a. Sudoku puzzles - `data/generated/puzzles_g{givens}_s{seed}_n{count}.json` (cache; rebuilt if missing)
| field | meaning |
|---|---|
| `puzzle` | 81 ints, row-major, 0 = empty cell |
| `solution` | 81 ints, the unique solution |
| `givens` | number of non-zero cells in `puzzle` |

*How made:* full grid by randomised backtracking (`random.Random(f"puzzle-{givens}-{seed}-{i}")`), then cells are
removed in random order while the solution stays **unique** (checked with the CSP solver) until `givens` remain.

### 3b. Instances and mosaics (made on the fly, deterministic in the seed)
| item | meaning |
|---|---|
| `image_idx` | 81 ints: index into the 9,020 test images used for that cell, -1 = blank |
| `injected` | cell indices (0-80) whose image is a *hard* digit, i.e. a deliberate misread |
| mosaic | 252x252 float32 in [0,1]: the 81 cells (28x28, row-major). Blank cells = `clip(N(0, 0.02^2), 0, 1)` noise |

*Clean pool:* test images the calibrated network reads correctly (8,814 images). *Hard pool* (138 images, 7-22 per
digit): test images the network **misreads** with calibrated top-1 confidence <= 0.90 while the true digit is still
in its top-3. (206 of 9,020 test images are misread; 73% of them have confidence <= 0.90, median misread confidence 0.69.)
To inject *m* misreads, *m* givens use hard images and all other givens use clean images, so the number of
misreads is exactly *m*. Hard images are reused across puzzles; they come from the test set, which is never used
for training, validation or temperature fitting.

## 4. Network outputs and results
| file | columns / content |
|---|---|
| `models/mlp.npz`, `models/logreg.npz` | weights `W0..`, `b0..`, `sizes`, fitted `temperature` |
| `results/classifier_metrics.json` | accuracy, NLL, ECE (raw and T-scaled), confusion matrix, reliability bins, training history |
| `results/tables/raw_search_runs.csv` | `seed, puzzle, misreads, actual_misreads, method, solved, recovered, expanded, generated, csp_calls, csp_assignments, csp_backtracks, cost, n_corrections, ms` (one row per instance and method) |
| `results/tables/raw_csp_runs.csv` | `givens, seed, puzzle, config, order, solved, limit_hit, assignments, backtracks, fc_prunes, ac3_prunes, ms` |
| `results/tables/exp*_*.csv/.md` | mean and std over the per-seed means of the raw runs |
| `results/tables/correction_logs.jsonl` | one JSON line per NN-guided run (methods UCS and A*+unique, 5,000 lines): `seed, puzzle, misreads, method, status, total_cost, corrections[cell, row, col, read, new, cost]` - the correction log required for every solved puzzle |
| `results/demo/demo_summary.json` | numbers of the demo instance (seed, search counters, UCS trace, CSP counters, domain sizes, NN on/off rates) used by the slides and the report |
| `results/hard_pool.json`, `results/optimality_check.json` | pool sizes; A* versus UCS cost comparison |

`solved` = the system returned a solvable puzzle; `recovered` = the returned solution equals the ground-truth solution.
