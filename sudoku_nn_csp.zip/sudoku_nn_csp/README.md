# Handwritten Sudoku Reader and Solver (Neural Network + Search + CSP)

Project **P7** of the *Search + CSP + Neural Network* brief. A computer reads a Sudoku written in handwritten
digits. Sometimes the network misreads a digit, which breaks the puzzle. The system finds the most likely
misreads, corrects them and solves the puzzle.

```
 handwritten 9x9 mosaic ──► NN (MLP, calibrated probabilities)
                               │ read grid + P(digit) per cell
                               ▼
                       AC-3: conflict in the givens?  ──no──► CSP solves ──► solution
                               │ yes
                               ▼
        Search (UCS / Greedy / A*) over correction sets, cost = -log likelihood ratio
                               │ proposes the cheapest corrected grid
                               ▼
        CSP (BT, FC, AC-3) tests it: solvable / unique?  ──no──► Search continues
                               │ yes
                               ▼
                 solution + correction log   (or "UNREADABLE" + least-confident cells)
```

## 1. Environment (pinned)
```bash
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
No GPU and no deep-learning framework are needed: the network is implemented in NumPy.

## 2. Exact run commands
```bash
python make_data.py
python train_nn.py
pytest -q
python run_demo.py
python run_experiments.py
python -m sudoku_rs.generator --seed 1 --givens 30 --misreads 2
python tools/build_report.py && python tools/build_slides.py
python tools/check_deliverables.py
```
What the commands do: `make_data.py` downloads MNIST and preprocesses it (about 15 s); `train_nn.py` trains the MLP and the logistic-regression baseline (about 20 s); `pytest -q` runs the 58 tests: 25 normal, 22 edge, 11 impossible (about 10 s); `run_demo.py` runs the integrated demo (about 10 s); `run_experiments.py` runs the three experiments (about 4 min, `--stage search` or `--stage csp` runs one half); `tools/check_deliverables.py` rechecks the deliverables and every number quoted in the report and slides.

Notes: `python run_demo.py --seed 12 --misreads 3` (any non-default option) writes to `results/demo_custom/`, the default run
writes `results/demo/`, which the report and slides use. `python run_experiments.py --quick` writes to `results/quick/`, never over the
full results. Bad input raises a `ValueError` with a clear message; UNREADABLE is a normal result (`status == "unreadable"`), not an error.
Outputs: `results/tables/*.csv|md`, `results/figures/*.png`, `results/demo/`, `results/classifier_metrics.json`.
Everything is deterministic given the seeds in `sudoku_rs/config.py` (`MASTER_SEED=2026`, experiment seeds 0-4).

### Windows / VS Code notes
* Open the folder that contains `README.md` (unzipping can create `sudoku_nn_csp\\sudoku_nn_csp`: use the inner one).
* PowerShell setup: `py -3.12 -m venv .venv`, `.venv\\Scripts\\Activate.ps1` (if scripts are blocked: `Set-ExecutionPolicy -Scope Process Bypass`), `pip install -r requirements.txt`.
* Run `python run_demo.py` in the terminal, or the VS Code run button. The scripts have no Unix `#!` line, and every text file is read
  and written as UTF-8 so Windows code pages cannot break them. If `numpy`/`matplotlib` import for a long time on the first run
  (antivirus, debugger), wait - do not press Ctrl+C. "Run Without Debugging" (Ctrl+F5) starts faster than the debugger.
* The processed MNIST data is not in the zip: `run_demo.py`, `train_nn.py` and `run_experiments.py` download and prepare it
  automatically on first use (about 11 MB). `models/mlp.npz` is included; `python train_nn.py` recreates it.
* Developed and tested on Python 3.12; the code needs Python 3.10 or newer. If `pip install -r requirements.txt` cannot find a pinned
  version for your Python, install the same packages without the `==` pins.

## 3. Layout
| path | content |
|---|---|
| `sudoku_rs/data.py` | download, MD5 check, preprocessing, blank-cell rule, mosaic helpers |
| `sudoku_rs/nn.py` | NumPy MLP / logistic regression, Adam, temperature scaling, ECE, confusion matrix |
| `sudoku_rs/csp.py` | Sudoku CSP: Backtracking, Forward Checking, AC-3 as separate switches + counters |
| `sudoku_rs/search.py` | UCS, Greedy best-first, A* over correction sets; random/no-correction baselines; brute-force checker |
| `sudoku_rs/generator.py` | seeded puzzle generator (unique solutions), hard-digit pools, mosaic renderer |
| `sudoku_rs/integration.py` | the integrated pipeline (`solve_mosaic`) and the correction log |
| `sudoku_rs/eval.py` | the three experiments, tables and plots |
| `make_data.py`, `train_nn.py`, `run_demo.py`, `run_experiments.py` | entry points |
| `tests/` | pytest suite (58 tests: 25 normal, 22 edge, 11 impossible) |
| `tools/` | `build_report.py`, `build_slides.py`, `check_deliverables.py` |
| `DATA_DICTIONARY.md`, `DEMO_SCRIPT.md`, `CONTRIBUTIONS.md`, `GIT_LOG.txt`, `report/`, `slides/` | documentation deliverables |

## 4. How each required deliverable is covered
| # | deliverable | where |
|---|---|---|
| 1 | clearly named modules (data, nn, search, csp, integration, eval, tests) | `sudoku_rs/`, `tests/` |
| 2 | reproducible data script, fixed seed | `make_data.py` (seed 2026) |
| 3 | data dictionary, real vs generated | `DATA_DICTIONARY.md` |
| 4 | trained NN + test results vs baseline | `train_nn.py`, `results/tables/classifier.md` (MLP vs logistic regression) |
| 5 | search with counters, small known example | `search.py` (generated / expanded / CSP calls), `tests/test_search.py::test_normal_known_example_seven_read_as_one` |
| 6 | CSP: BT, FC, AC-3 switchable + counters | `csp.solve(use_fc=, use_ac3=, var_order=)`; counters: assignments, backtracks, fc_prunes, ac3_prunes |
| 7 | one integrated demo | `python run_demo.py` |
| 8 | README, pinned requirements, run commands | this file, `requirements.txt` |
| 9 | tests: >=5 normal, >=3 edge, >=2 impossible | `tests/test_csp.py`, `test_search.py`, `test_pipeline.py` (names start `test_normal_`, `test_edge_`, `test_impossible_`) |
| 10 | 3 experiments, tables+plots, 5 seeds, mean ± std | `python run_experiments.py` -> `results/` |
| 11 | report (max 12 pages) | `report/report.pdf` |
| 12 | 10-min presentation + 5-min demo | `slides/presentation.pptx`, `DEMO_SCRIPT.md` |
| 13 | contribution statement + git log | `CONTRIBUTIONS.md`, `GIT_LOG.txt` |

P7-specific items: calibrated classifier vs logistic regression (accuracy, confusion matrix, ECE) in `results/`;
seeded puzzle + mosaic generator; correction log per solved puzzle (cell, read digit, new digit, cost) printed by
`PipelineResult.text()`, and saved for every NN-guided experiment run in `results/tables/correction_logs.jsonl`; exact-solution recovery on 100 puzzles per misread level per seed (500 in total).

## 5. Design choices in one paragraph
*Search:* a state is a set of corrections to the first reading; cost = ln p(read) − ln p(new) ≥ 0, so the cheapest
state is the maximum-likelihood correction. Only the 12 least-confident givens may change, each to one of its 2 best
alternatives (probability ≥ 1e-4), at most 3 changes. *Goal:* the CSP finds a solution (minimum version) or exactly
one solution (extension `goal="unique"`). *A\* heuristic:* pairs of equal digits in a unit must lose a cell, and a
maximal set of disjoint conflicts is priced at the cheaper cell's cheapest alternative - admissible (tested against
brute force in every state). *CSP:* 9-bit domain masks; AC-3 on the != arcs; FC removes the assigned digit from peers.
*Blank cells* are found by a brightness rule, not by the network.

## 6. Known limits (see the report)
Synthetic puzzles built from MNIST digits, not photos of real Sudoku; misreads are *injected* from a documented pool,
so recovery rates describe that pool, not natural error rates; a solvable-but-wrong corrected puzzle can pass the
"solvable" goal (use `goal="unique"`); more misreads than the correction cap cannot be repaired.
