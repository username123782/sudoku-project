import json
import sys
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, KeepTogether, Paragraph, SimpleDocTemplate, Table, TableStyle

ROOT = Path(__file__).resolve().parents[1]
R, T, F = ROOT / "results", ROOT / "results" / "tables", ROOT / "results" / "figures"
OUT = ROOT / "report" / "report.pdf"
sys.path.insert(0, str(Path(__file__).parent))
from _counts import count_tests

TC = count_tests()
DEMO_SEED = json.loads((R / "demo" / "demo_summary.json").read_text(encoding="utf-8"))["seed"]

ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["Normal"], fontName="Helvetica", fontSize=9.3, leading=12.2, spaceAfter=5)
H1 = ParagraphStyle("h1", parent=ss["Heading2"], fontSize=12.5, spaceBefore=9, spaceAfter=4, textColor=colors.HexColor("#1f3a5f"))
H2 = ParagraphStyle("h2", parent=ss["Heading3"], fontSize=10.3, spaceBefore=6, spaceAfter=3)
CAP = ParagraphStyle("cap", parent=BODY, fontSize=8, leading=10, textColor=colors.HexColor("#444444"), spaceAfter=7)
TITLE = ParagraphStyle("title", parent=ss["Title"], fontSize=18, leading=22, spaceAfter=4)
CELL = ParagraphStyle("cell", parent=BODY, fontSize=7.6, leading=9, spaceAfter=0)


def P(t, st=BODY):
    return Paragraph(t, st)


def fig(name, width_cm, caption):
    from PIL import Image as PI
    w, h = PI.open(F / name).size
    return KeepTogether([Image(str(F / name), width=width_cm * cm, height=width_cm * cm * h / w), P(caption, CAP)])


def table(rows, widths, header=True, fs=7.6):
    t = Table([[Paragraph(str(c), CELL) for c in r] for r in rows], colWidths=[w * cm for w in widths], repeatRows=1)
    st = [("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#999999")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]
    if header:
        st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dfe7f2")))
    t.setStyle(TableStyle(st))
    return t


def ms(row, m, nd):
    return f"{row[m + '_mean']:.{nd}f} ± {0 if pd.isna(row[m + '_std']) else row[m + '_std']:.{nd}f}"


clf = json.loads((R / "classifier_metrics.json").read_text(encoding="utf-8"))
hp = json.loads((R / "hard_pool.json").read_text(encoding="utf-8"))
opt = json.loads((R / "optimality_check.json").read_text(encoding="utf-8"))
e1, e2, e3 = (pd.read_csv(T / f"{n}.csv") for n in ("exp1_search", "exp2_csp", "exp3_nn_effect"))
mlp, lr = clf["mlp"], clf["logreg"]

s = []
IDST = ParagraphStyle("idst", parent=BODY, fontName="Helvetica-Bold", fontSize=11, leading=14, spaceAfter=10)
s += [P("Name: Fares Sameh Ibrahim<br/>ID: 320240064", IDST),
      P("Handwritten Sudoku Reader and Solver", TITLE)]

s += [P("1. Problem", H1),
      P("A computer reads a Sudoku written in handwritten digits. A digit classifier sometimes misreads a digit, and one wrong "
        "given usually makes the puzzle unsolvable (two equal digits in a row) or, worse, solvable but wrong. The system "
        "must find the most likely misreads, correct them and solve the puzzle. Three AI techniques cooperate: a "
        "<b>neural network</b> reads the 81 cells and outputs a probability for every digit; a <b>search</b> proposes "
        "correction sets in order of likelihood; a <b>CSP solver</b> (backtracking, forward checking, AC-3) tests "
        "whether a corrected grid is a valid puzzle and solves it. If no admissible correction exists the system answers "
        "<i>unreadable</i> and lists the least confident cells instead of guessing."),
      P("<b>Scope.</b> This is a decision-support/teaching system evaluated on synthetic Sudokus built from MNIST digits; "
        "it is not a photograph-to-Sudoku product (see section 8).")]

s += [P("2. Data: what is real and what is generated", H1),
      P("<b>Real:</b> MNIST (60,000 training and 10,000 test images of 28x28 pixels, test writers differ from training writers). "
        "Files are downloaded from a mirror and verified against the official MD5 sums. Digit 0 is dropped (Sudoku has 1-9). "
        "The 60,000 training images are split with a seeded permutation (seed 2026) into 50,000 train / 10,000 validation; "
        "after removing zeros the sizes are 45,069 / 9,008 / 9,020 images for train / validation / test. "
        "The test set is used once for the final numbers."),
      P("<b>Generated (documented rules, all seeded):</b> (a) <i>Puzzles:</i> a full grid by randomised backtracking, then cells are "
        "removed in random order while the solution stays unique (checked with the CSP solver) until 25, 30 or 35 givens "
        "remain. (b) <i>Mosaics:</i> each given is a random MNIST test image of that digit placed in a 9x9 grid (252x252 px); each "
        "blank is Gaussian noise (sigma 0.02). Blank cells are detected by a brightness rule (fewer than 10 pixels above 0.5), "
        "not by the network; the rule separates all 9,020 test digits from noise cells perfectly (tested). "
        "(c) <i>Injected misreads:</i> a network that is 97.7% accurate leaves little to correct, so misreads are injected from a "
        "<b>hard pool</b>: test images that the calibrated network misreads with confidence &lt;= 0.90 while the true digit is still in "
        f"its top 3 ({hp['hard_pool_size']} images, 7-22 per digit; {hp['misclassified']} of {hp['test_images']} test images are misread "
        f"and {100 * hp['share_of_misreads_with_conf_le_0.9']:.0f}% of those have confidence &lt;= 0.90). All other givens come from the "
        f"correctly read pool ({hp['clean_pool_size']:,} images), so a puzzle with <i>m</i> injected misreads has exactly <i>m</i> misread "
        "givens (asserted in every experiment run). The full field-by-field description is in DATA_DICTIONARY.md.")]

s += [P("3. Neural network", H1),
      P("The classifier is a NumPy MLP 784-128-9 (ReLU, softmax, Adam, L2 1e-4, early stopping on validation NLL, 14 s training). "
        "The baseline is multinomial logistic regression (784-9) trained with the same optimiser. The network's probabilities are not "
        "only a classification result: they define the <b>cost of changing a cell</b> in the search, so calibration matters. "
        "Temperature scaling is fitted on the validation set. Calibration is measured with the expected calibration error (ECE, 15 equal-width bins).")]
rows = [["model", "test accuracy", "NLL", "ECE raw", "ECE after T-scaling", "T"]]
for key, lab in (("logreg", "Logistic regression"), ("mlp", "MLP 784-128-9")):
    r = clf[key]
    rows.append([lab, f"{r['test_calibrated']['accuracy']:.4f}", f"{r['test_calibrated']['nll']:.4f}", f"{r['test_raw']['ece']:.4f}",
                 f"{r['test_calibrated']['ece']:.4f}", f"{r['temperature']:.3f}"])
s += [table(rows, [4.2, 2.6, 2.2, 2.2, 3.4, 1.6]), P("Table 1. Classifier results on the test set.", CAP),
      P(f"The MLP beats the baseline by {100 * (mlp['test_calibrated']['accuracy'] - lr['test_calibrated']['accuracy']):.1f} accuracy points and is "
        f"already well calibrated (ECE {mlp['test_raw']['ece']:.4f}); the fitted temperature is close to 1 (0.975) and scaling does "
        f"<i>not</i> improve it (ECE {mlp['test_calibrated']['ece']:.4f}). It helps the weaker logistic regression only slightly "
        f"({lr['test_raw']['ece']:.4f} to {lr['test_calibrated']['ece']:.4f}). We keep the scaled probabilities because the procedure is "
        f"standard and harmless here. Errors concentrate on visually similar pairs (confusion matrix, Figure 1).")]
from reportlab.platypus import Table as T2
imgs = T2([[Image(str(F / "classifier_confusion.png"), width=7.4 * cm, height=7.4 * cm * 4.6 / 5.2),
            Image(str(F / "classifier_reliability.png"), width=7.4 * cm, height=7.4 * cm * 4.4 / 4.8)]])
s += [KeepTogether([imgs, P("Figure 1. MLP confusion matrix (left) and reliability diagram (right).", CAP)])]

s += [P("4. Search over corrections", H1),
      P("<b>State</b> = the set of corrections made to the first reading, stored as a sorted tuple, so every set is reachable in exactly one way. "
        "<b>Action</b> = change one more <i>uncertain</i> cell to one of its top alternative digits. Only the 12 least-confident givens may change, "
        "each to one of its 2 best other digits whose probability is at least 1e-4, at most <b>3 corrections</b> (the brief's limit). "
        "<b>Cost</b> of changing a cell from the read digit r to d is ln p(r) - ln p(d) &gt;= 0 (never negative, how much less likely d is); the cost of a "
        "state is the sum, i.e. the negative log likelihood ratio of the corrected grid against the first reading, so the cheapest state is the "
        "<i>most likely correction set</i>. <b>Goal</b> = the CSP finds a solution (minimum version) or exactly one solution "
        "(extension). Search counters: nodes generated, nodes expanded (popped and goal-tested), CSP calls, and the CSP's own assignments and backtracks."),
      P("<b>Algorithms.</b> UCS orders by g and returns the optimal set. Greedy best-first orders by h (ties by g) and is fast but not optimal. A* orders by g + h. "
        "<b>Heuristic.</b> Two equal digits in one row, column or box force at least one of the two cells to change. We pick a maximal set of "
        "vertex-disjoint conflicts greedily; every picked conflict needs a distinct changed cell, which costs at least the cheapest alternative "
        "of the cheaper cell, so the sum is a lower bound; a conflict whose two cells cannot change gives h = infinity (dead state). "
        "h is admissible because solvable grids have no conflicts. We verified this empirically in every state of a full search tree "
        "against exhaustive enumeration (tests/test_search.py), and in Experiment 1 A* returned exactly the UCS cost on all "
        f"{opt['instances_where_UCS_and_A*_both_solved']:,} instances where both succeeded ({opt['A*_cost_differs_from_UCS']} differences). "
        "The goal test first applies a cheap duplicate-digit check (identical to what the first AC-3 pass detects for fully specified givens) "
        "and calls the CSP only on conflict-free grids.")]

s += [P("5. CSP", H1),
      P("Variables are the 81 cells, domains are 9-bit masks of digits 1-9 (givens have singleton domains), constraints are 'not equal' between the 20 "
        "peers of a cell. Three parts are separate switches: <b>Backtracking</b> (always on; assigns cells one by one and checks row/column/box), "
        "<b>Forward Checking</b> (after an assignment removes the digit from all peer domains and backtracks on an empty domain) and "
        "<b>AC-3</b> (run once before search; for a not-equal arc a value only loses support when the other domain is a singleton, so it "
        "propagates singletons; two equal givens in a unit empty a domain, which is how conflicts are detected). Variable ordering is a fourth, independent "
        "switch (static row-major or MRV). Counters: assignments, backtracks, FC prunes, AC-3 revisions and prunes. Uniqueness is tested by asking for 2 solutions. "
        "Impossible puzzles return status 'no_solution' with the message 'NO SOLUTION: ...' stating whether AC-3, the given check or exhausted search found it.")]

s += [P("6. Integration", H1),
      P("<b>Read</b>: the network reads each non-blank cell and gives P(digit). <b>Check</b>: AC-3 on the givens finds a conflict, or the first reading is "
        "already solvable. <b>Search</b> proposes the cheapest correction set; the <b>CSP</b> accepts the first corrected grid that is solvable/unique; "
        "otherwise search continues. The output is the solution plus a <b>correction log</b> (cell, read digit, new digit, cost). If the budget (3 corrections, 12 candidate "
        "cells) is exhausted the answer is <b>UNREADABLE</b> with the least confident cells. 'NN off' modes replace the probabilities by nothing "
        "(solve the first reading) or by random correction sets with the same CSP test (300 tries). Figure 2 shows one run of run_demo.py.")]
s += [fig("../demo/demo_overview.png", 16.8, f"Figure 2. Demo run (seed {DEMO_SEED}, 2 misreads).")]

s += [P("7. Experiments", H1),
      P("<b>Setup.</b> Every cell of every table is a mean ± standard deviation over the per-seed means of <b>5 seeds</b> (0-4); each seed uses 100 new puzzles per "
        "condition (500 per condition). Experiments 1 and 3 use 30-given puzzles and 0-4 injected misreads; Experiment 2 uses 25, 30, 35 givens and a node limit of "
        "1,000,000 assignments. <i>Recovery</i> = the returned solution equals the ground-truth solution; <i>solved</i> = the system returned some solvable puzzle. In the tables, 'A*+unique' is A* with the goal 'exactly one solution', 'cap 4' allows 4 instead of 3 corrections, and cost is the negative log-likelihood ratio of the returned correction set.")]

s += [P("7.1 Experiment 1: UCS vs Greedy vs A* (nodes, cost, recovery)", H2)]
rows = [["misreads", "method", "recovery", "nodes expanded", "CSP calls", "cost"]]
for lvl in range(5):
    for m in ["UCS", "Greedy", "A*", "A*+unique"] + (["A*+unique (cap 4)"] if lvl == 4 else []):
        r = e1[(e1.misreads == lvl) & (e1.method == m)].iloc[0]
        rows.append([lvl, m, ms(r, "recovered", 3), ms(r, "expanded", 1), ms(r, "csp_calls", 2), ms(r, "cost", 2)])
s += [table(rows, [1.6, 3.6, 2.6, 3.0, 2.4, 2.4]),
      P("Table 2. Search comparison by number of misreads.", CAP),
      fig("exp1_search.png", 14.5, "Figure 3. Search effort and recovery by number of misreads."),
      P(f"<b>Findings.</b> (1) A* and UCS return the same cost everywhere, but A* expands far fewer nodes (2 misreads: 3.8 vs 7.7; 3 misreads: 8.5 vs 26.4). "
        f"(2) Greedy is not optimal: its cost was above UCS's in {opt['greedy_cost_above_UCS']} of {opt['greedy_instances_compared']:,} comparable instances "
        f"(mean cost ratio {opt['greedy_mean_cost_ratio_vs_UCS']:.2f} on instances with non-zero UCS cost) and it often expands more nodes than UCS (16.9 vs 7.7 at 2 misreads) because the "
        f"conflict heuristic is flat on conflict-free grids. (3) With the 'solvable' goal recovery falls from 1.00 to 0.85, 0.70 and 0.63 for 1-3 misreads: "
        f"the cheapest solvable grid is sometimes a <i>different</i> solvable puzzle (a misread that creates no conflict, or a cheaper wrong change). "
        f"Requiring exactly one solution lifts recovery to 0.97, 0.89 and 0.87, at the price of about 1 extra CSP call. (4) With 4 misreads and the 3-correction cap exact recovery is 0, "
        f"as it must be; worse, the system still returns <i>some</i> solvable grid in 52% (solvable goal) and 25% (unique goal) of these cases, which would be silently wrong. "
        f"Allowing 4 corrections recovers 0.76.")]

s += [P("7.2 Experiment 2: BT vs BT+FC vs BT+FC+AC-3", H2)]
rows = [["order", "givens", "config", "assignments", "backtracks", "time (ms)", "solved within limit"]]
for order in ("static", "mrv"):
    for g in (25, 30, 35):
        for cfg in ("BT", "BT+FC", "BT+FC+AC-3"):
            r = e2[(e2.order == order) & (e2.givens == g) & (e2.config == cfg)].iloc[0]
            rows.append([order, g, cfg, ms(r, "assignments", 0), ms(r, "backtracks", 0), ms(r, "ms", 2), ms(r, "solved", 3)])
s += [table(rows, [1.5, 1.3, 2.7, 3.2, 3.2, 2.5, 2.6]),
      P("Table 3. CSP counters by configuration, ordering and number of givens.", CAP),
      fig("exp2_csp.png", 15.5, "Figure 4. Mean assignments per configuration, static order (left) and MRV order (right)."),
      P("<b>Findings.</b> Runs that hit the 1,000,000-assignment limit count as unsolved and enter the means at the limit, so the BT value at 25 givens is a lower bound (7 of 500 runs). With the classic static order, Forward Checking cuts assignments by about 4x at 25 givens (64,462 to 14,785) and AC-3 before search a further 1.6x "
        "(9,343); on 35 givens the same chain reduces 654 to 203 to 81. The effect grows as the puzzle gets harder (fewer givens). AC-3's cost is a fixed ~340 value removals per puzzle, "
        "so on easy puzzles it does not pay in time (1.6 ms vs 0.4 ms at 35 givens) but at 25 givens it saves time (16.7 ms vs 23.5 ms for FC alone and 45.2 ms for BT). "
        "With MRV ordering all three configurations need only 330-401 assignments at 25 givens: MRV recomputes the legal digits of every cell from the row/column/box masks, which is the same "
        "pruning that FC performs incrementally, and picking forced cells first subsumes what AC-3 propagates. So AC-3 changes nothing in assignments under MRV and only adds time. "
        "The practical lesson: variable ordering matters more than the propagation switches, and FC/AC-3 are worth most when the ordering is naive.")]

s += [P("7.3 Experiment 3: NN-guided vs no correction vs random correction", H2)]
rows = [["misreads", "method", "recovery", "solved", "CSP calls"]]
for lvl in range(5):
    for m in ("NN-guided (UCS)", "No correction", "Random"):
        r = e3[(e3.misreads == lvl) & (e3.method == m)].iloc[0]
        rows.append([lvl, m, ms(r, "recovered", 3), ms(r, "solved", 3), ms(r, "csp_calls", 1)])
s += [table(rows, [1.8, 4.0, 3.0, 3.0, 2.6]),
      P("Table 4. Effect of the neural network on recovery.", CAP),
      fig("exp3_nn_effect.png", 8.6, "Figure 5. Exact-solution recovery versus injected misreads."),
      P("<b>Findings.</b> Without the network the system cannot repair anything: not correcting recovers 0% from one misread upwards, and random correction recovers 18% at one misread and 0% beyond, "
        "although it often finds <i>a</i> solvable grid (77% at one misread), which is a wrong answer. NN-guided correction recovers 85% / 70% / 63% for 1-3 misreads (97% / 89% / 87% with the uniqueness goal). "
        "The probabilities turn a very large space of corrections into a short ordered list: NN-guided runs need only 1.2-2.5 CSP calls on average, random correction 1-5 calls and still fails.")]

s += [P("8. Testing", H1),
      P(f"The pytest suite ({TC['total']} tests, under a minute) has 5+ normal, 3+ edge and 2+ impossible cases across the suite (the CSP and search files each have all three groups). <i>Normal:</i> known puzzle solved by every switch combination; AC-3 prunes without removing "
        "solution values; FC and AC-3 reduce assignments; generator yields unique solutions with the requested givens; the spec example (a digit read as 3 at 0.52 vs true 5 at 0.45) gives the one-change answer with cost ln(0.52/0.45); UCS and A* equal the brute-force optimum; "
        "the heuristic is admissible in every state; the pipeline recovers one misread. <i>Edge:</i> complete grid, empty grid (solvable, not unique), single missing cell, zero misreads, zero allowed corrections, "
        "tied probabilities, deterministic generation. <i>Impossible:</i> duplicate givens and consistent-but-unsolvable puzzles give 'NO SOLUTION' in all CSP configurations; a confidently misread conflict, or "
        "more misreads than the cap, gives 'UNREADABLE' with the least confident cells. <i>Robustness:</i> malformed puzzles, unknown options and wrong mosaic shapes raise clear "
        "errors, quick experiment runs are written to a separate folder, and the demo handles zero misreads, too few givens and an UNREADABLE result.")]

s += [P("9. Limits", H1),
      P("<b>Synthetic input.</b> Mosaics are built from isolated MNIST digits on a clean grid; real photographed Sudokus add lines, skew, lighting and printed digits, which the system does not handle. "
        "<b>Injected misreads.</b> Recovery rates describe the documented hard pool (138 images reused across 500 puzzles), not natural error rates; 27% of natural misreads have confidence above 0.90 and the "
        "search by construction cannot find them (the correct digit would have to be among the 12 least-confident cells). "
        "<b>Silent wrong answers.</b> A corrected grid that is solvable (even unique) is not proof of correctness; with more misreads than the cap, or a cheaper wrong set, the system can return a valid but wrong Sudoku. "
        "A threshold on the total correction cost, or asking the user to confirm the changed cells, would mitigate this; we did not evaluate it. "
        "<b>Search restrictions.</b> 12 candidate cells, 2 alternatives each and at most 3 changes make the search small and fast (under 10 ms per puzzle on this machine) but are a trade-off against recall. "
        "<b>Calibration.</b> Temperature scaling gave no gain on the MLP; calibration on test digits does not guarantee calibration on handwriting from other sources. "
        "<b>Statistics.</b> Standard deviations are across 5 seeds of 100 puzzles; puzzles within a seed share the hard pool, so seeds are not fully independent samples. "
        "<b>Implementation.</b> Pure Python/NumPy: absolute timings are machine-dependent; only counters are comparable across machines.")]

s += [P("10. Conclusions", H1),
      P("A small calibrated network, an informed search and a CSP form a system in which each part does what it is good at: the network turns pixels into probabilities, the search turns probabilities into an "
        "ordered list of plausible repairs, and the CSP provides the ground truth about whether a repair yields a valid puzzle. A* with the conflict heuristic is optimal and the cheapest search; Greedy is neither. "
        "Forward checking and AC-3 pay off when variable ordering is naive and puzzles are hard, while MRV removes most of the difference. Switching the network off removes essentially all ability to repair misreads. "
        "The main open problems are the silent wrong answers when the correction budget is exceeded and the gap between injected and natural misreads.")]


def footer(c, d):
    c.saveState()
    c.setFont("Helvetica", 7.5)
    c.drawCentredString(A4[0] / 2, 1.0 * cm, f"Handwritten Sudoku Reader and Solver - page {d.page}")
    c.restoreState()


OUT.parent.mkdir(exist_ok=True)
SimpleDocTemplate(str(OUT), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                  title="Handwritten Sudoku Reader and Solver", author="").build(s, onFirstPage=footer, onLaterPages=footer)
from pypdf import PdfReader

n = len(PdfReader(str(OUT)).pages)
print(f"wrote {OUT} ({n} pages)")
sys.exit(0 if n <= 12 else "report exceeds 12 pages")
