import json
import sys
from pathlib import Path

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).parent))
from _counts import count_tests

TC = count_tests()
F, D = ROOT / "results" / "figures", ROOT / "results" / "demo"
S = json.loads((D / "demo_summary.json").read_text(encoding="utf-8"))
NAVY, GREY, ACC = RGBColor(0x1F, 0x3A, 0x5F), RGBColor(0x44, 0x44, 0x44), RGBColor(0x2E, 0x7D, 0x32)

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)


def slide(title):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    tb = s.shapes.add_textbox(Inches(0.6), Inches(0.35), Inches(12.1), Inches(0.9))
    p = tb.text_frame.paragraphs[0]
    p.text = title
    p.font.size, p.font.bold, p.font.color.rgb, p.font.name = Pt(30), True, NAVY, "Calibri"
    p.alignment = PP_ALIGN.LEFT
    return s


def bullets(s, items, x, y, w, h, size=16):
    tf = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)).text_frame
    tf.word_wrap = True
    for i, it in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        head, sep, rest = it.partition("|")
        r = p.add_run()
        r.text = ("• " + head) if sep else "• " + it
        r.font.size, r.font.bold, r.font.name, r.font.color.rgb = Pt(size), bool(sep), "Calibri", GREY
        if rest:
            r2 = p.add_run()
            r2.text = rest
            r2.font.size, r2.font.name, r2.font.color.rgb = Pt(size), "Calibri", GREY
        p.space_after = Pt(7)


def table(s, rows, x, y, colw, size=13):
    t = s.shapes.add_table(len(rows), len(rows[0]), Inches(x), Inches(y), Inches(sum(colw)), Inches(0.38 * len(rows))).table
    for j, cw in enumerate(colw):
        t.columns[j].width = Inches(cw)
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            c = t.cell(i, j)
            c.text = str(v)
            for p in c.text_frame.paragraphs:
                p.font.size, p.font.name = Pt(size), "Calibri"


def pic(s, path, x, y, w, h):
    iw, ih = Image.open(path).size
    k = min(w / iw, h / ih)
    s.shapes.add_picture(str(path), Inches(x + (w - iw * k) / 2), Inches(y), Inches(iw * k), Inches(ih * k))


def note(s, text, x, y, w, size=14, color=ACC):
    p = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(0.9)).text_frame
    p.word_wrap = True
    r = p.paragraphs[0].add_run()
    r.text, r.font.size, r.font.bold, r.font.name, r.font.color.rgb = text, Pt(size), True, "Calibri", color


s = slide("Handwritten Sudoku Reader and Solver")
note(s, "Name: Fares Sameh Ibrahim        ID: 320240064", 0.6, 1.25, 12, 20, NAVY)
steps = ["Handwritten\n9x9 mosaic", "NN reads digits\n+ probabilities", "AC-3 finds a\nconflict", "Search: cheapest\ncorrections (UCS/A*)",
         "CSP tests and\nsolves (BT/FC/AC-3)", "Solution +\ncorrection log"]
for i, t in enumerate(steps):
    box = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.5 + i * 2.1), Inches(2.5), Inches(1.85), Inches(1.3))
    box.fill.solid()
    box.fill.fore_color.rgb = RGBColor(0xDF, 0xE7, 0xF2)
    box.line.color.rgb = NAVY
    tf = box.text_frame
    tf.word_wrap = True
    tf.text = t
    for p in tf.paragraphs:
        p.alignment = PP_ALIGN.CENTER
        p.font.size, p.font.color.rgb, p.font.name = Pt(13), NAVY, "Calibri"
bullets(s, ["Problem|: one misread digit makes a Sudoku unsolvable (or solvable but wrong)",
            "Idea|: use the network's probabilities as the cost of changing a cell; search for the most likely repair; let the CSP decide",
            "If no repair works|: answer UNREADABLE and list the least confident cells"], 0.7, 4.4, 12, 2.4, 18)

s = slide("What goes wrong: from pixels to a broken puzzle")
pic(s, D / "input_mosaic.png", 0.7, 1.5, 5.0, 5.0)
bad = "; ".join(f"r{c['row']}c{c['col']} read {c['read']}, true {c['new']}" for c in S["corrections"])
bullets(s, [f"Input|: {S['givens']} handwritten givens on a 9x9 mosaic, blank cells are noise",
            f"The network misreads {S['misreads']} cells|: {bad}",
            "AC-3 on the reading|: two equal digits in one unit empty a domain, so the puzzle looks impossible",
            "Goal|: the cheapest corrections that give a solvable, unique puzzle - or UNREADABLE"], 6.2, 1.6, 6.7, 5.0, 19)

s = slide("Data and neural network")
bullets(s, ["Real|: MNIST digits 1-9, 45,069 / 9,008 / 9,020 images (seeded split, test untouched)",
            "Generated|: unique-solution puzzles (25-35 givens), 9x9 mosaics, blank noise, hard-digit pool (138 misreads, confidence <= 0.90)",
            "MLP 784-128-9|: 97.7% test accuracy vs 92.4% for logistic regression",
            "Calibrated|: ECE 0.004 (temperature 0.975, scaling gives no gain)",
            "Probabilities become costs|: cost(read → new) = ln p(read) - ln p(new)"], 0.6, 1.4, 6.6, 5.4, 18)
pic(s, F / "classifier_confusion.png", 7.6, 1.5, 5.2, 4.9)

s = slide("Calibration and the hard-digit rule")
bullets(s, ["Why calibration|: cost = ln p(read) - ln p(new) only works if probabilities are honest",
            "Result|: ECE 0.004 for the MLP (0.020 for logistic regression); scaling gives no gain",
            "Hard pool|: 138 test images misread with confidence <= 0.90, true digit in the top 3 (73% of the 206 test errors)",
            "Clean pool|: 8,814 correctly read images, so a puzzle with m misreads has exactly m (asserted in every run)",
            "Hard images come from the test set, never from training, validation or temperature fitting"], 0.6, 1.4, 6.6, 5.5, 17)
pic(s, F / "classifier_reliability.png", 7.6, 1.5, 5.2, 4.9)

s = slide("Search: the most likely correction set")
bullets(s, ["State|: set of corrections to the first reading (max 3)", "Action|: change one of the 12 least-confident cells to a top-2 alternative",
            "Goal|: CSP finds a solution (extension: exactly one)", "Heuristic|: equal digits in a unit must lose a cell: disjoint conflicts x cheapest alternative (admissible)",
            "Result|: A* cost = UCS cost on 2,259 / 2,259 instances; 3.8 vs 7.7 (UCS) vs 16.9 (Greedy) nodes at 2 misreads"], 0.6, 1.4, 5.2, 5.6, 17)
pic(s, F / "exp1_search.png", 5.9, 2.0, 7.2, 3.0)

s = slide("Search trace: UCS tries the cheapest repairs first")
rows = [["#", "corrections tried (row, col: read → new)", "cost g", "CSP test"]]
for t in S["trace_ucs"]:
    rows.append([t["order"], ", ".join(f"r{r}c{c}: {a}→{b}" for r, c, a, b in t["corrections"]) or "none (first reading)",
                 f"{t['g']:.3f}", "passes" if t["goal"] else "fails"])
table(s, rows, 0.6, 1.2, [0.6, 6.4, 1.3, 1.4], 13)
a = S["search"]
bullets(s, [f"Same optimal cost {a['ucs']['cost']:.3f}|: UCS expands {a['ucs']['expanded']} nodes, A* {a['astar']['expanded']}, Greedy {a['greedy']['expanded']}",
            "Why|: A* uses the conflict heuristic; Greedy is blind on conflict-free grids"], 0.6, 6.0, 12, 1.4, 16)

s = slide("CSP: Backtracking, Forward Checking and AC-3 as separate switches")
bullets(s, ["BT|: assign cells, check row / column / box", "FC|: remove the digit from peer domains, backtrack on an empty domain",
            "AC-3|: run before search, shrinks domains, detects equal givens", "Counters|: assignments, backtracks, prunes",
            "25 givens, static order|: BT 64,462 → FC 14,785 → FC+AC-3 9,343 assignments", "MRV order|: all three need 330-401, ordering matters most"], 0.6, 1.4, 5.0, 5.6, 17)
pic(s, F / "exp2_csp.png", 5.7, 2.0, 7.4, 2.8)

s = slide("Integrated system and live demo")
pic(s, D / "demo_overview.png", 0.5, 1.3, 8.4, 5.4)
c = S["csp"]
bullets(s, ["python run_demo.py|", "1. Search trace|: UCS tries the first reading, single changes, then pairs",
            f"2. CSP pruning|: assignments BT {c['BT']['assignments']:,} → FC {c['BT+FC']['assignments']:,} → FC+AC-3 {c['BT+FC+AC-3']['assignments']:,}; domains {S['domains'][0]} → {S['domains'][1]}",
            f"3. NN on vs off|: {100 * S['on_off']['NN on (UCS)']:.0f}% vs 0% recovery ({S['misreads']} misreads)",
            "Best case for AC-3; Exp 2 average at 25 givens: 1.6x fewer than FC"], 9.1, 1.5, 4.0, 5.2, 16)

s = slide("The network is what makes repair possible")
pic(s, F / "exp3_nn_effect.png", 0.6, 1.4, 5.8, 4.5)
bullets(s, ["Recovery, 1 / 2 / 3 misreads|:", "NN-guided: 0.85 / 0.70 / 0.63 (exactly-one goal: 0.97 / 0.89 / 0.87)",
            "No correction: 0 / 0 / 0", "Random correction: 0.18 / 0 / 0", "4 misreads > 3 allowed corrections|: UNREADABLE, but 25-52% of runs still return a wrong grid",
            "Experiment 3|: 5 seeds x 100 puzzles per level"], 6.8, 1.5, 6.2, 5.2, 18)

s = slide("Testing and reproducibility")
bullets(s, [f"{TC['total']} tests|: {TC['normal']} normal, {TC['edge']} edge, {TC['impossible']} impossible (all pass in under a minute)",
            "Impossible cases|: the CSP prints NO SOLUTION; the pipeline prints UNREADABLE with the least confident cells",
            "Known answer|: a digit read as 3 (0.52) instead of 5 (0.45) gives the one-change fix, cost ln(0.52/0.45)",
            "Search checked|: UCS and A* equal brute force; the A* heuristic is admissible in every state",
            "Reproducible|: MD5-verified data, fixed seeds; a clean clone gives the same accuracy and demo output",
            "Logs|: 5,000 per-puzzle correction logs in results/tables/correction_logs.jsonl"], 0.7, 1.5, 12, 5.4, 19)

s = slide("Limits and conclusions")
bullets(s, ["Limits|: synthetic Sudokus from MNIST digits, not photographs; misreads are injected from a 138-image hard pool",
            "Limits|: a solvable (even unique) corrected grid is not proof of correctness; need a cost threshold or user confirmation",
            "Limits|: the correct digit must be among the 12 least-confident cells; 27% of natural misreads are confident and out of reach",
            "Conclusions|: calibrated probabilities + A* + CSP repair 63-97% of 1-3 misreads; without the NN, 0-18%",
            "Conclusions|: A* is optimal and cheapest; FC / AC-3 pay off most with naive ordering on hard puzzles"], 0.7, 1.5, 12, 5.4, 20)

(ROOT / "slides").mkdir(exist_ok=True)
prs.save(str(ROOT / "slides" / "presentation.pptx"))
print("wrote slides/presentation.pptx")
