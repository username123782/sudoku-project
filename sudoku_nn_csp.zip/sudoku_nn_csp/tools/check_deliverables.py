import json
import re
import subprocess
import sys
from pathlib import Path

import pandas as pd
from pptx import Presentation
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
T, R = ROOT / "results" / "tables", ROOT / "results"
from sudoku_rs import config as _C

_C.safe_console()
bad = 0


def check(name, cond, detail=""):
    global bad
    bad += not cond
    print(("PASS  " if cond else "FAIL  ") + name + (f"  [{detail}]" if detail else ""))


def warn(name, detail):
    print(f"WARN  {name}  [{detail}]")


norm = lambda t: re.sub(r"\s+", " ", t)
report = norm(" ".join(p.extract_text() for p in PdfReader(ROOT / "report" / "report.pdf").pages))
deck = Presentation(ROOT / "slides" / "presentation.pptx")


def slide_text(sl):
    out = []
    for sh in sl.shapes:
        if sh.has_text_frame:
            out.append(sh.text_frame.text)
        if getattr(sh, "has_table", False) and sh.has_table:
            out += [c.text for row in sh.table.rows for c in row.cells]
    return " ".join(out)


slides = norm(" ".join(slide_text(s) for s in deck.slides))

check("1 modules data/nn/search/csp/integration/eval + tests/", all((ROOT / "sudoku_rs" / f"{m}.py").exists() for m in
      "data nn search csp integration eval".split()) and (ROOT / "tests").is_dir())
man = ROOT / "data" / "processed" / "manifest.json"
if man.exists():
    m = json.loads(man.read_text(encoding="utf-8"))
    check("2 make_data.py + fixed seed + MD5 of 4 files", (ROOT / "make_data.py").exists() and m["seed"] == 2026 and len(m["md5"]) == 4)
else:
    warn("2 manifest", "data/processed missing - run make_data.py to check the seed/MD5 record")
dd = (ROOT / "DATA_DICTIONARY.md").read_text(encoding="utf-8")
cols = set(pd.read_csv(T / "raw_search_runs.csv").columns) | set(pd.read_csv(T / "raw_csp_runs.csv").columns)
check("3 data dictionary names every results column", all(c in dd for c in cols), str([c for c in cols if c not in dd]))
check("3 dictionary marks real vs generated", "real" in dd.lower() and "generated" in dd.lower() and "correction_logs" in dd)
cm = json.loads((R / "classifier_metrics.json").read_text(encoding="utf-8"))
acc = {k: v["test_calibrated"]["accuracy"] for k, v in cm.items()}
check("4 NN beats the logistic-regression baseline on the test set", acc["mlp"] > acc["logreg"] and (ROOT / "train_nn.py").exists(),
      f"{acc['mlp']:.4f} vs {acc['logreg']:.4f}")
sr = pd.read_csv(T / "raw_search_runs.csv")
check("5 search counters (expanded, generated) + known-answer test", {"expanded", "generated"} <= set(sr.columns) and
      "test_normal_known_example_seven_read_as_one" in (ROOT / "tests" / "test_search.py").read_text(encoding="utf-8"))
from sudoku_rs import csp
from tests.helpers import PUZZLE, SOLUTION

combos = [(fc, ac) for fc in (0, 1) for ac in (0, 1)]
rs = [csp.solve(PUZZLE, use_fc=bool(fc), use_ac3=bool(ac)) for fc, ac in combos]
check("6 BT/FC/AC-3 switches all solve; counters present", all(r.solutions[0] == SOLUTION for r in rs) and
      all(hasattr(rs[0].counters, k) for k in ("assignments", "backtracks", "fc_prunes", "ac3_prunes")))
check("7 demo script + overview plot + summary", all(p.exists() for p in (ROOT / "run_demo.py", R / "demo" / "demo_overview.png", R / "demo" / "demo_summary.json")))
readme = (ROOT / "README.md").read_text(encoding="utf-8")
reqs = [l for l in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
check("8 README commands + pinned requirements", all(c in readme for c in ("pip install -r requirements.txt", "python make_data.py",
      "python train_nn.py", "python run_demo.py", "python run_experiments.py", "pytest")) and all("==" in l for l in reqs))
col = subprocess.run([sys.executable, "-m", "pytest", "--collect-only", "-q"], cwd=ROOT, capture_output=True, text=True).stdout
cnt = {k: len(re.findall(rf"::test_{k}_", col)) for k in ("normal", "edge", "impossible")}
total = sum(cnt.values())
run = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=ROOT, capture_output=True, text=True)
check("9 tests: >=5 normal, >=3 edge, >=2 impossible, all passing", cnt["normal"] >= 5 and cnt["edge"] >= 3 and cnt["impossible"] >= 2
      and run.returncode == 0, f"{cnt}; {run.stdout.strip().splitlines()[-1]}")
sc = pd.read_csv(T / "raw_csp_runs.csv")
per_level = sr.groupby(["method", "misreads"]).puzzle.count().min()
check("10 experiments: >=5 seeds, >=100 puzzles per level, tables+plots", sr.seed.nunique() >= 5 and sc.seed.nunique() >= 5 and per_level >= 100
      and all((T / f"{n}.md").exists() for n in ("exp1_search", "exp2_csp", "exp3_nn_effect"))
      and all((R / "figures" / f"{n}.png").exists() for n in ("exp1_search", "exp2_csp", "exp3_nn_effect")), f"{per_level} runs per method and level")
check("10 P7: correction log per puzzle saved", sum(1 for _ in open(T / "correction_logs.jsonl", encoding="utf-8")) == 2 * 5 * 500)
pages = len(PdfReader(ROOT / "report" / "report.pdf").pages)
first_page = norm(PdfReader(ROOT / "report" / "report.pdf").pages[0].extract_text())
first_slide = slide_text(deck.slides[0])
check("no tagline lines in report and slides", "Project P7 of the Search" not in report and "constraint satisfaction | Project P7" not in slides)
name_at = first_page.find("Name: Fares Sameh Ibrahim ID: 320240064")
check("name and ID at the start of the report and on the first slide", 0 <= name_at < first_page.find("1. Problem")
      and "Name: Fares Sameh Ibrahim" in first_slide and "ID: 320240064" in first_slide)
check("11 report <= 12 pages with required sections", pages <= 12 and all(w in report for w in ("Problem", "Neural network", "Integration", "Limits", "Conclusions")), f"{pages} pages")
check("12 slides cover trace, CSP pruning, NN on/off + demo script", all(w in slides.lower() for w in ("trace", "forward checking", "nn on vs off", "ac-3"))
      and (ROOT / "DEMO_SCRIPT.md").exists(), f"{len(deck.slides)} slides")
stmt = (ROOT / "CONTRIBUTIONS.md").read_text(encoding="utf-8").split("## ", 1)[1]
check("13 contribution statement <= 200 words + git log exported", len(stmt.split()) <= 200 and (ROOT / "GIT_LOG.txt").exists(), f"{len(stmt.split())} words")
if "[Your name]" in stmt:
    warn("13 contribution statement", "still a template - the student must fill in their own part")
authors = subprocess.run(["git", "log", "--format=%an"], cwd=ROOT, capture_output=True, text=True).stdout.split()
if len(set(authors)) < 2:
    warn("13 git log", "single generic author - commit your own work under your own name")

e1, e2, e3 = (pd.read_csv(T / f"{n}.csv") for n in ("exp1_search", "exp2_csp", "exp3_nn_effect"))
opt = json.loads((R / "optimality_check.json").read_text(encoding="utf-8"))
S = json.loads((R / "demo" / "demo_summary.json").read_text(encoding="utf-8"))
x1 = lambda m, l, c: float(e1[(e1.method == m) & (e1.misreads == l)][c + "_mean"].iloc[0])
x2 = lambda o, g, cf, c: float(e2[(e2.order == o) & (e2.givens == g) & (e2.config == cf)][c + "_mean"].iloc[0])
x3 = lambda m, l, c: float(e3[(e3.method == m) & (e3.misreads == l)][c + "_mean"].iloc[0])
nn_ = "NN-guided (UCS)"
lim = int(sc[(sc.order == "static") & (sc.config == "BT") & (sc.givens == 25)].limit_hit.sum())
mrv = [x2("mrv", 25, c, "assignments") for c in ("BT", "BT+FC", "BT+FC+AC-3")]
claims = [
    ("report", f"{x1('A*', 2, 'expanded'):.1f} vs {x1('UCS', 2, 'expanded'):.1f}"), ("report", f"{x1('A*', 3, 'expanded'):.1f} vs {x1('UCS', 3, 'expanded'):.1f}"),
    ("report", f"{x1('Greedy', 2, 'expanded'):.1f} vs {x1('UCS', 2, 'expanded'):.1f}"), ("slides", f"{x1('A*', 2, 'expanded'):.1f} vs {x1('UCS', 2, 'expanded'):.1f} (UCS) vs {x1('Greedy', 2, 'expanded'):.1f}"),
    ("report", f"{opt['instances_where_UCS_and_A*_both_solved']:,}"), ("slides", f"{opt['instances_where_UCS_and_A*_both_solved']:,} / {opt['instances_where_UCS_and_A*_both_solved']:,}"),
    ("report", f"in {opt['greedy_cost_above_UCS']} of"),
    ("report", f"{x1('A*', 4, 'solved') * 100:.0f}% (solvable goal) and {x1('A*+unique', 4, 'solved') * 100:.0f}% (unique goal)"),
    ("report", f"recovers {x1('A*+unique (cap 4)', 4, 'recovered'):.2f}"),
    ("report", f"{x2('static', 25, 'BT', 'assignments'):,.0f} to {x2('static', 25, 'BT+FC', 'assignments'):,.0f}"), ("report", f"({x2('static', 25, 'BT+FC+AC-3', 'assignments'):,.0f})"),
    ("report", f"{x2('static', 35, 'BT', 'assignments'):,.0f} to {x2('static', 35, 'BT+FC', 'assignments'):,.0f} to {x2('static', 35, 'BT+FC+AC-3', 'assignments'):,.0f}"),
    ("slides", f"BT {x2('static', 25, 'BT', 'assignments'):,.0f} → FC {x2('static', 25, 'BT+FC', 'assignments'):,.0f} → FC+AC-3 {x2('static', 25, 'BT+FC+AC-3', 'assignments'):,.0f}"),
    ("report", f"{min(mrv):.0f}-{max(mrv):.0f} assignments"), ("slides", f"{min(mrv):.0f}-{max(mrv):.0f}"),
    ("report", f"{x2('static', 35, 'BT+FC+AC-3', 'ms'):.1f} ms vs {x2('static', 35, 'BT+FC', 'ms'):.1f} ms"),
    ("report", f"{x2('static', 25, 'BT+FC+AC-3', 'ms'):.1f} ms vs {x2('static', 25, 'BT+FC', 'ms'):.1f} ms for FC alone and {x2('static', 25, 'BT', 'ms'):.1f} ms for BT"),
    ("report", f"{lim} of 500"),
    ("slides", f"{x3(nn_, 1, 'recovered'):.2f} / {x3(nn_, 2, 'recovered'):.2f} / {x3(nn_, 3, 'recovered'):.2f}"),
    ("report", f"{x3('Random', 1, 'recovered') * 100:.0f}% at one misread"), ("report", f"({x3('Random', 1, 'solved') * 100:.0f}% at one misread)"),
    ("slides", f"{acc['mlp'] * 100:.1f}% test accuracy vs {acc['logreg'] * 100:.1f}%"),
    ("slides", f"domains {S['domains'][0]} → {S['domains'][1]}"), ("slides", f"{100 * S['on_off']['NN on (UCS)']:.0f}% vs 0% recovery"),
    ("report", f"seed {S['seed']}, 2 misreads"),
    ("slides", f"{cnt['normal']} normal, {cnt['edge']} edge, {cnt['impossible']} impossible"),
    ("slides", f"{total} tests"), ("report", f"({total} tests"), ("readme", f"{total} tests: {cnt['normal']} normal, {cnt['edge']} edge, {cnt['impossible']} impossible"),
]
texts = {"report": report, "slides": slides, "readme": readme}
miss = [(d, c) for d, c in claims if c not in texts[d]]
check(f"quoted numbers match result files ({len(claims)} claims)", not miss, str(miss))
ms_ = float(sr[sr.method == "A*"].ms.mean())
check("'under 10 ms per puzzle' claim", ms_ < 10, f"A* mean {ms_:.1f} ms")
print("\nALL CHECKS PASSED" if not bad else f"\n{bad} CHECK(S) FAILED")
sys.exit(1 if bad else 0)
