import re
import subprocess
import sys
from pathlib import Path


def count_tests(root=None) -> dict:
    root = Path(root or Path(__file__).resolve().parents[1])
    out = subprocess.run([sys.executable, "-m", "pytest", "--collect-only", "-q"], cwd=root, capture_output=True, text=True).stdout
    c = {k: len(re.findall(rf"::test_{k}_", out)) for k in ("normal", "edge", "impossible")}
    c["total"] = sum(c.values())
    return c
