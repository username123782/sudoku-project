import argparse
import json
import time


from sudoku_rs import config as C
from sudoku_rs import data, nn


def main():
    C.safe_console()
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=20)
    args = ap.parse_args()
    d = data.load_processed(auto_prepare=True)
    C.MODELS.mkdir(exist_ok=True)
    C.RESULTS.mkdir(exist_ok=True)
    out = {}
    for name, sizes in (("mlp", (784, 128, 9)), ("logreg", (784, 9))):
        print(f"== training {name} {sizes}")
        net = nn.MLP(sizes, seed=C.MASTER_SEED)
        t0 = time.time()
        hist = net.fit(d["X_train"], d["y_train"], d["X_val"], d["y_val"], epochs=args.epochs, seed=C.MASTER_SEED)
        T = nn.fit_temperature(net.logits(d["X_val"]), d["y_val"])
        net.save(C.MODELS / f"{name}.npz", temperature=T)
        raw, cal = nn.evaluate(net, d["X_test"], d["y_test"], 1.0), nn.evaluate(net, d["X_test"], d["y_test"], T)
        p = net.predict_proba(d["X_test"], T)
        out[name] = {
            "sizes": list(sizes), "train_seconds": round(time.time() - t0, 1), "temperature": T,
            "test_raw": raw, "test_calibrated": cal, "history": hist,
            "confusion_matrix": nn.confusion_matrix(d["y_test"], p.argmax(1)).tolist(),
            "reliability_raw": nn.reliability_bins(net.predict_proba(d["X_test"]), d["y_test"]),
            "reliability_cal": nn.reliability_bins(p, d["y_test"]),
        }
        print(f"  T={T:.3f}  test raw={raw}  calibrated={cal}")
    (C.RESULTS / "classifier_metrics.json").write_text(json.dumps(out, indent=1, default=lambda o: o.item()), encoding="utf-8")
    print("saved models/ and results/classifier_metrics.json")


if __name__ == "__main__":
    main()
