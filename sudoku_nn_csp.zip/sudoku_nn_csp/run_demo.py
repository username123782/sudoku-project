import argparse
import json
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

from sudoku_rs import config as C
from sudoku_rs import csp, data, nn
from sudoku_rs import generator as G
from sudoku_rs import integration as I

OUT = C.RESULTS / "demo"


def draw_grid(ax, grid, title, shade=None, colors=None, boxed=()):
    ax.set_xlim(0, 9)
    ax.set_ylim(9, 0)
    ax.set_aspect("equal")
    ax.axis("off")
    for k in range(10):
        lw = 2.2 if k % 3 == 0 else 0.5
        ax.plot([0, 9], [k, k], "k", lw=lw)
        ax.plot([k, k], [0, 9], "k", lw=lw)
    for i, v in enumerate(grid):
        r, c = divmod(i, 9)
        if shade and i in shade:
            ax.add_patch(Rectangle((c, r), 1, 1, color=shade[i], alpha=0.55, lw=0))
        if i in boxed:
            ax.add_patch(Rectangle((c + .06, r + .06), .88, .88, fill=False, ec="red", lw=2))
        if v:
            ax.text(c + .5, r + .55, str(v), ha="center", va="center", fontsize=13,
                    color=(colors or {}).get(i, "black"))
    ax.set_title(title, fontsize=10)


def pick_instance(args, d, model, T, pools):
    for seed in range(args.seed, args.seed + 60):
        base = G.generate_puzzle_set(args.givens, seed, 1, cache=False)[0]
        inst = G.make_instance(base["puzzle"], args.misreads, pools, random.Random(f"demo-{seed}"))
        mosaic = G.render_mosaic(inst["image_idx"], d["X_test"], seed)
        read = I.read_mosaic(mosaic, model, T)
        if not args.auto or args.misreads == 0:
            return seed, base, inst, mosaic, read
        res = I.solve_read(read, algo="astar", goal=args.goal)
        if read.grid != base["puzzle"] and csp.ac3_conflict(read.grid) and res.solution == base["solution"]:
            fc = csp.solve(base["puzzle"], use_fc=True, use_ac3=False, var_order="static").counters.assignments
            ac = csp.solve(base["puzzle"], use_fc=True, use_ac3=True, var_order="static").counters.assignments
            if ac < fc:
                return seed, base, inst, mosaic, read
    raise SystemExit("no demo instance in 60 seeds has misreads that create a conflict AND are repaired with the given "
                     "--goal/--misreads/--givens; try another --seed, fewer --misreads (at most 3 corrections are allowed), or --no-auto")


def main():
    C.safe_console()
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=3)
    ap.add_argument("--misreads", type=int, default=2)
    ap.add_argument("--givens", type=int, default=26)
    ap.add_argument("--goal", default="unique", choices=["solvable", "unique"])
    ap.add_argument("--no-auto", dest="auto", action="store_false", help="use the given seed as it is")
    ap.add_argument("--out", default=None, help="output folder (default: results/demo for the default run, results/demo_custom otherwise)")
    args = ap.parse_args()
    global OUT
    custom = (args.seed, args.misreads, args.givens, args.goal) != (3, 2, 26, "unique")
    OUT = Path(args.out) if args.out else C.RESULTS / ("demo_custom" if custom else "demo")
    OUT.mkdir(parents=True, exist_ok=True)
    try:
        d = data.load_processed(auto_prepare=True)
        model, T = nn.MLP.load(C.MODELS / "mlp.npz")
    except FileNotFoundError as exc:
        raise SystemExit(f"error: {exc}")
    pools = G.build_pools(d, model, T)
    try:
        seed, base, inst, mosaic, read = pick_instance(args, d, model, T, pools)
    except ValueError as exc:
        raise SystemExit(f"error: {exc}")
    truth, sol = base["puzzle"], base["solution"]
    wrong = {i for i in range(81) if read.grid[i] != truth[i]}
    plt.imsave(OUT / "input_mosaic.png", mosaic, cmap="gray")

    print(f"=== 1. INPUT  (seed {seed}: {base['givens']} handwritten givens, {len(wrong)} injected misreads) ===")
    print("ground-truth puzzle (for reference):")
    print(I.format_grid(truth))
    print(f"handwritten 9x9 mosaic (252x252 px) saved to {OUT / 'input_mosaic.png'}")

    print("\n=== 2. NN READING  (* = demo-only marker of a real misread) ===")
    print(I.format_grid(read.grid, marks=wrong))
    low = sorted((c, read.probs[c].max()) for c in range(81) if read.grid[c])
    low = sorted(low, key=lambda t: t[1])[:6]
    print("least confident cells:", ", ".join(f"r{c // 9 + 1}c{c % 9 + 1}={p:.2f}" for c, p in low))

    print("\n=== 3. AC-3 CONFLICT CHECK ===")
    pairs = csp.conflict_pairs(read.grid)
    print("AC-3 empties a domain:", csp.ac3_conflict(read.grid), "| duplicate-digit conflicts:",
          [(f"r{a // 9 + 1}c{a % 9 + 1}", f"r{b // 9 + 1}c{b % 9 + 1}", read.grid[a]) for a, b in pairs[:6]])

    print(f"\n=== 4. SEARCH over corrections (goal = {args.goal}, max {C.MAX_CORRECTIONS} corrections) ===")
    runs = {}
    for algo in ("ucs", "greedy", "astar"):
        r = I.solve_read(read, algo=algo, goal=args.goal, trace_limit=300)
        runs[algo] = r
        c = r.search.counters
        print(f"{algo:7s} status={r.status:8s} cost={r.cost:6.3f} expanded={c.expanded:4d} generated={c.generated:5d} "
              f"csp_calls={c.csp_calls:3d} exact={r.solution == sol}")
    print("\nUCS search trace (first 10 expansions: corrections tried as (row,col,read->new), g, CSP goal test):")
    for t in runs["ucs"].search.trace[:10]:
        corr = ", ".join(f"r{r}c{c}:{a}->{b}" for r, c, a, b in t["corrections"]) or "(none: first reading)"
        print(f"  #{t['order']:2d}  g={t['g']:.3f}  {corr:40s} goal={t['goal']}")
    best = runs["astar"]
    print("\ncorrection log (A*):")
    print(best.text())
    if best.status != "solved":
        print("\n=== RESULT: UNREADABLE - no solution is reported (nothing is guessed) ===")
        fig, axs = plt.subplots(1, 2, figsize=(11, 5.4))
        axs[0].imshow(mosaic, cmap="gray")
        axs[0].axis("off")
        axs[0].set_title("handwritten input", fontsize=10)
        unsure = {(r - 1) * 9 + c - 1 for r, c, _ in best.least_confident}
        draw_grid(axs[1], read.grid, "UNREADABLE: least confident cells boxed", boxed=unsure)
        fig.tight_layout()
        fig.savefig(OUT / "demo_overview.png", dpi=140)
        print(f"plot saved: {OUT / 'demo_overview.png'}")
        return

    print("\n=== 5. CSP pruning on the corrected puzzle (static row-major order) ===")
    corrected = read.grid[:]
    for cor in best.corrections:
        corrected[cor["cell"]] = cor["new"]
    sizes0, sizes1 = sum(csp.domain_sizes(corrected, False)), sum(csp.domain_sizes(corrected, True))
    print(f"total domain size before AC-3: {sizes0}   after AC-3: {sizes1}")
    csp_rows = {}
    for name, (fc, ac) in {"BT": (0, 0), "BT+FC": (1, 0), "BT+FC+AC-3": (1, 1)}.items():
        r = csp.solve(corrected, use_fc=bool(fc), use_ac3=bool(ac), var_order="static")
        csp_rows[name] = r.counters
        k = r.counters
        print(f"{name:11s} assignments={k.assignments:6d} backtracks={k.backtracks:6d} fc_prunes={k.fc_prunes:6d} "
              f"ac3_prunes={k.ac3_prunes:4d}  solved={r.solved}")

    print("\n=== 6. SYSTEM WITH NN ON vs OFF (30 fresh puzzles, same misread level) ===")
    rates = {}
    for label, kw in {"NN on (UCS)": dict(algo="ucs", goal=args.goal), "NN off: no correction": dict(mode="none"),
                      "NN off: random": dict(mode="random")}.items():
        ok = 0
        puzzles = G.generate_puzzle_set(args.givens, 900, 30)
        for i, p in enumerate(puzzles):
            ins = G.make_instance(p["puzzle"], args.misreads, pools, random.Random(f"onoff-{i}"))
            rd = I.read_mosaic(G.render_mosaic(ins["image_idx"], d["X_test"], i), model, T)
            kw2 = dict(kw, rng=random.Random(i)) if kw.get("mode") == "random" else kw
            ok += I.solve_read(rd, **kw2).solution == p["solution"]
        rates[label] = ok / len(puzzles)
        print(f"{label:24s} exact-solution recovery: {ok}/{len(puzzles)} = {rates[label]:.2f}")

    print("\n=== 7. FINAL SOLUTION ===")
    print(I.format_grid(best.solution))
    print("matches ground truth:", best.solution == sol, "| valid Sudoku:", csp.is_valid_solution(best.solution, corrected))
    if best.solution != sol:
        print("WARNING: a valid but WRONG Sudoku - the correction budget was exceeded or a cheaper wrong correction set exists")

    fig = plt.figure(figsize=(15, 8.6))
    ax = fig.add_subplot(2, 3, 1)
    ax.imshow(mosaic, cmap="gray")
    ax.axis("off")
    ax.set_title("1. handwritten input (MNIST test digits)", fontsize=10)
    conf_shade = {i: "orange" for i in range(81) if read.grid[i] and read.probs[i].max() < 0.9}
    draw_grid(fig.add_subplot(2, 3, 2), read.grid,
              "2. NN reading (orange = confidence < 0.9, red box = real misread)", conf_shade, boxed=wrong)
    cells_corr = {c["cell"] for c in best.corrections}
    colors = {i: "red" for i in cells_corr} | {i: "tab:blue" for i in range(81) if corrected[i] == 0}
    draw_grid(fig.add_subplot(2, 3, 3), best.solution,
              "3. corrections (red) + CSP fills (blue) = solution", colors=colors, boxed=cells_corr)
    ax = fig.add_subplot(2, 3, 4)
    for algo, st in (("ucs", "o-"), ("greedy", "s--"), ("astar", "^-.")):
        tr = runs[algo].search.trace
        ax.plot([t["order"] for t in tr], [t["g"] for t in tr], st, ms=3, label=algo.upper() if algo != "astar" else "A*")
        ax.plot(tr[-1]["order"], tr[-1]["g"], "k*", ms=11)
    ax.set_xlabel("expansion order")
    ax.set_ylabel("path cost g of expanded node")
    ax.set_title("search trace (star = goal found)", fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(alpha=.3)
    ax = fig.add_subplot(2, 3, 5)
    ax.bar(list(csp_rows), [max(v.assignments, 1) for v in csp_rows.values()], color=["tab:gray", "tab:blue", "tab:green"])
    ax.set_yscale("log")
    ax.set_ylabel("assignments (log)")
    ax.set_title(f"CSP pruning (domains {sizes0} -> {sizes1} after AC-3)", fontsize=10)
    ax = fig.add_subplot(2, 3, 6)
    ax.bar(list(rates), list(rates.values()), color=["tab:green", "tab:gray", "tab:orange"])
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("exact-solution recovery")
    ax.set_title(f"NN on vs off ({args.misreads} misreads, 30 puzzles)", fontsize=10)
    plt.setp(ax.get_xticklabels(), fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT / "demo_overview.png", dpi=140)
    summary = {"seed": seed, "misreads": args.misreads, "givens": base["givens"], "goal": args.goal,
               "misread_cells": sorted(wrong),
               "search": {a: {"cost": r.cost, **{k: getattr(r.search.counters, k) for k in ("expanded", "generated", "csp_calls")},
                              "exact": r.solution == sol} for a, r in runs.items()},
               "trace_ucs": runs["ucs"].search.trace[:12], "csp": {k: v.as_dict() for k, v in csp_rows.items()},
               "domains": [sizes0, sizes1], "on_off": rates, "corrections": best.corrections}
    (OUT / "demo_summary.json").write_text(json.dumps(summary, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o)), encoding="utf-8")
    print(f"\nplots saved: {OUT / 'demo_overview.png'} and {OUT / 'input_mosaic.png'}")


if __name__ == "__main__":
    main()
