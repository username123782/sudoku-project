import numpy as np

P = "530070000600195000098000060800060003400803001700020006060000280000419005000080079"
S = "534678912672195348198342567859761423426853791713924856961537284287419635345286179"
PUZZLE = [int(c) for c in P]
SOLUTION = [int(c) for c in S]


def synthetic_probs(grid, conf=0.99):
    p = np.zeros((81, 9))
    for i, v in enumerate(grid):
        if v:
            p[i] = (1 - conf) / 8
            p[i, v - 1] = conf
    return p


def two_way(p, cell, read, alt, p_read=0.52, p_alt=0.45):
    p[cell] = (1 - p_read - p_alt) / 7
    p[cell, read - 1], p[cell, alt - 1] = p_read, p_alt
    return p
