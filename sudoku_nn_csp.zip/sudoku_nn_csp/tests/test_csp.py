import itertools

import pytest

from helpers import PUZZLE, SOLUTION
from sudoku_rs import csp, generator as G

CONFIGS = list(itertools.product([False, True], [False, True], ["static", "mrv"]))


@pytest.mark.parametrize("fc,ac,order", CONFIGS)
def test_normal_known_puzzle_every_switch_combination(fc, ac, order):
    r = csp.solve(PUZZLE, use_fc=fc, use_ac3=ac, var_order=order)
    assert r.solved and r.solutions[0] == SOLUTION and csp.is_valid_solution(r.solutions[0], PUZZLE)


def test_normal_ac3_prunes_domains_and_keeps_solution_values():
    before, after = csp.domain_sizes(PUZZLE, use_ac3=False), csp.domain_sizes(PUZZLE, use_ac3=True)
    assert sum(after) < sum(before)
    assert all(a >= 1 for a in after)
    assert all(((1 << (SOLUTION[i] - 1)) & m) for i, m in enumerate(_doms(PUZZLE)))


def _doms(grid):
    d = csp.initial_domains(grid)
    assert csp.ac3(d, csp.CSPCounters())
    return d


def test_normal_forward_checking_and_ac3_reduce_backtracking():
    puzzles = G.generate_puzzle_set(25, 0, 5, cache=False)
    tot = {}
    for name, (fc, ac) in {"bt": (False, False), "fc": (True, False), "fc_ac3": (True, True)}.items():
        tot[name] = sum(csp.solve(p["puzzle"], use_fc=fc, use_ac3=ac, var_order="static").counters.assignments
                        for p in puzzles)
    assert tot["fc"] < tot["bt"] and tot["fc_ac3"] <= tot["fc"]


def test_normal_counters_are_reported():
    c = csp.solve(PUZZLE, use_fc=True, use_ac3=True, var_order="static").counters
    assert c.assignments > 0 and c.ac3_revisions > 0 and c.ac3_prunes > 0
    c2 = csp.solve(G.generate_puzzle_set(25, 1, 1, cache=False)[0]["puzzle"], use_fc=True, use_ac3=False,
                   var_order="static").counters
    assert c2.fc_prunes > 0 and c2.backtracks > 0


def test_normal_generator_gives_unique_solutions_with_requested_givens():
    for g in (25, 30, 35):
        for p in G.generate_puzzle_set(g, 3, 3, cache=False):
            assert p["givens"] == g and csp.count_solutions(p["puzzle"]) == 1
            assert csp.solve(p["puzzle"]).solutions[0] == p["solution"]


def test_edge_complete_grid_needs_no_assignments():
    r = csp.solve(SOLUTION, use_fc=True, use_ac3=True)
    assert r.solved and r.solutions[0] == SOLUTION and r.counters.assignments == 0


def test_edge_empty_grid_is_solvable_but_not_unique():
    for fc, ac in [(False, False), (True, False), (True, True)]:
        r = csp.solve([0] * 81, use_fc=fc, use_ac3=ac, var_order="mrv")
        assert r.solved and csp.is_valid_solution(r.solutions[0])
    assert csp.count_solutions([0] * 81, limit=2) == 2


def test_edge_single_missing_cell():
    p = SOLUTION[:]
    p[40] = 0
    r = csp.solve(p, use_fc=False, use_ac3=False, var_order="static")
    assert r.solved and r.solutions[0] == SOLUTION and r.counters.assignments == 1


@pytest.mark.parametrize("fc,ac", [(False, False), (True, False), (True, True)])
def test_impossible_duplicate_givens_give_clear_message(fc, ac):
    p = [0] * 81
    p[0] = p[8] = 5
    r = csp.solve(p, use_fc=fc, use_ac3=ac)
    assert r.status == "no_solution" and r.solutions == [] and "NO SOLUTION" in r.message
    assert csp.ac3_conflict(p)


@pytest.mark.parametrize("fc,ac", [(False, False), (True, False), (True, True)])
def test_impossible_consistent_but_unsolvable_puzzle(fc, ac):
    p = [0] * 81
    p[:8] = [1, 2, 3, 4, 5, 6, 7, 8]
    p[17] = 9
    assert csp.conflict_pairs(p) == []
    r = csp.solve(p, use_fc=fc, use_ac3=ac, var_order="mrv")
    assert r.status == "no_solution" and "NO SOLUTION" in r.message
