import pytest

from sudoku_rs import config as C
from sudoku_rs import data, nn


@pytest.fixture(scope="session")
def mnist():
    try:
        return data.load_processed()
    except FileNotFoundError:
        pytest.skip("run `python make_data.py` first")


@pytest.fixture(scope="session")
def mlp():
    if not (C.MODELS / "mlp.npz").exists():
        pytest.skip("run `python train_nn.py` first")
    return nn.MLP.load(C.MODELS / "mlp.npz")
