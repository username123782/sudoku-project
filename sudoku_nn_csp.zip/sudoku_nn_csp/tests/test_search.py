import math
import random

import numpy as np
import pytest

from helpers import PUZZLE, SOLUTION, synthetic_probs, two_way
from sudoku_rs import integration as I
from sudoku_rs import search


def corrupted_problem(rng, n_wrong=2, **kw):
    grid = PUZZLE[:]
    probs = synthetic_probs(grid)
    cells = rng.sample([i for i, v in enumerate(grid) if v], n_wrong)
    for c in cells:
        wrong = rng.choice([d for d in range(1, 10) if d != SOLUTION[c]])
        grid[c] = wrong
        two_way(probs, c, wrong, SOLUTION[c], 0.50, 0.40)
    return search.CorrectionProblem(grid, probs, **kw), cells


def test_normal_known_example_seven_read_as_one():
    grid = PUZZLE[:]
    grid[0] = 3
    probs = two_way(synthetic_probs(grid), 0, 3, 5)
    for algo in ("ucs", "greedy", "astar"):
        res = search.best_first(search.CorrectionProblem(grid, probs), algo)
        assert res.status == "solved" and res.solution == SOLUTION
        assert [(c["row"], c["col"], c["read"], c["new"]) for c in res.corrections] == [(1, 1, 3, 5)]
        assert res.cost == pytest.approx(math.log(0.52 / 0.45))
        assert res.counters.expanded >= 1 and res.counters.generated >= res.counters.expanded


def test_normal_ucs_and_astar_match_brute_force_optimum():
    for seed in range(6):
        prob, _ = corrupted_problem(random.Random(seed), n_wrong=2, n_cand=6, goal="solvable")
        best_cost, best_state = search.brute_force_optimum(prob)
        for algo in ("ucs", "astar"):
            res = search.best_first(prob, algo)
            if best_state is None:
                assert res.status == "unreadable"
            else:
                assert res.cost == pytest.approx(best_cost)


def test_normal_heuristic_is_admissible_in_every_state():
    for seed in range(4):
        prob, _ = corrupted_problem(random.Random(100 + seed), n_wrong=2, n_cand=5)
        states, stack = [], [()]
        while stack:
            s = stack.pop()
            states.append(s)
            stack.extend(ch for ch, _ in prob.successors(s))
        goals = [s for s in states if prob.goal_test(s, search.SearchCounters())[0]]
        for s in states:
            below = [prob.state_cost(g) - prob.state_cost(s) for g in goals if g[:len(s)] == s]
            assert prob.heuristic(s) <= (min(below) if below else math.inf) + 1e-9


def test_normal_greedy_and_astar_never_cost_less_than_ucs():
    for seed in range(6):
        prob, _ = corrupted_problem(random.Random(200 + seed), n_wrong=2)
        c = {a: search.best_first(prob, a) for a in ("ucs", "greedy", "astar")}
        assert c["greedy"].cost >= c["ucs"].cost - 1e-9
        assert c["astar"].cost == pytest.approx(c["ucs"].cost)
        assert c["astar"].counters.expanded <= c["ucs"].counters.expanded


def test_normal_uniqueness_goal_rejects_ambiguous_puzzles():
    grid = [0] * 81
    prob_s = search.CorrectionProblem(grid, np.zeros((81, 9)), goal="solvable")
    prob_u = search.CorrectionProblem(grid, np.zeros((81, 9)), goal="unique")
    assert search.best_first(prob_s, "ucs").status == "solved"
    assert search.best_first(prob_u, "ucs").status == "unreadable"


def test_edge_clean_reading_needs_zero_corrections():
    res = search.best_first(search.CorrectionProblem(PUZZLE, synthetic_probs(PUZZLE)), "ucs")
    assert res.status == "solved" and res.corrections == [] and res.cost == 0 and res.counters.expanded == 1


def test_edge_zero_corrections_allowed_means_unreadable():
    grid = PUZZLE[:]
    grid[0] = 3
    prob = search.CorrectionProblem(grid, two_way(synthetic_probs(grid), 0, 3, 5), max_corrections=0)
    assert search.best_first(prob, "astar").status == "unreadable"


def test_edge_ties_between_equally_likely_digits():
    grid = PUZZLE[:]
    grid[0] = 3
    probs = two_way(synthetic_probs(grid), 0, 3, 5, 0.45, 0.45)
    res = search.best_first(search.CorrectionProblem(grid, probs), "ucs")
    assert res.status == "solved" and res.cost == pytest.approx(0.0) and res.solution == SOLUTION


def test_impossible_confident_conflict_reports_unreadable_with_cells():
    grid = PUZZLE[:]
    grid[0] = 3
    res = search.best_first(search.CorrectionProblem(grid, synthetic_probs(grid, conf=1.0)), "ucs")
    assert res.status == "unreadable" and res.message.startswith("UNREADABLE")
    assert "r1c1" in res.message or "least confident" in res.message.lower()
    pipe = I.solve_read(I.ReadResult(grid, synthetic_probs(grid, conf=1.0), np.zeros(81, bool)))
    assert pipe.status == "unreadable" and len(pipe.least_confident) == 5


def test_impossible_puzzle_with_no_valid_completion():
    p = [0] * 81
    p[:8] = [1, 2, 3, 4, 5, 6, 7, 8]
    p[17] = 9
    res = search.best_first(search.CorrectionProblem(p, synthetic_probs(p, conf=1.0)), "ucs")
    assert res.status == "unreadable" and "UNREADABLE" in res.message


def test_impossible_more_misreads_than_the_cap_allows():
    rng = random.Random(5)
    prob, _ = corrupted_problem(rng, n_wrong=4, max_corrections=3, goal="unique")
    res = search.best_first(prob, "astar")
    assert res.status == "unreadable" or res.solution != SOLUTION
