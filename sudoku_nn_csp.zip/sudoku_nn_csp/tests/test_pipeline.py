import random

import numpy as np

from sudoku_rs import config as C
from sudoku_rs import data, nn
from sudoku_rs import generator as G
from sudoku_rs import integration as I


def test_normal_classifier_beats_logistic_regression_on_untouched_test_set(mnist, mlp):
    model, T = mlp
    base, Tb = nn.MLP.load(C.MODELS / "logreg.npz")
    acc = lambda m, t: (m.predict_proba(mnist["X_test"], t).argmax(1) == mnist["y_test"]).mean()
    assert acc(model, T) > 0.96 and acc(model, T) > acc(base, Tb) + 0.03


def test_normal_calibration_error_is_small(mnist, mlp):
    model, T = mlp
    assert nn.ece(model.predict_proba(mnist["X_test"], T), mnist["y_test"]) < 0.02


def test_normal_blank_rule_and_mosaic_round_trip(mnist):
    X = mnist["X_test"][:500]
    assert not data.is_blank(X).any()
    noise = np.clip(np.random.default_rng(0).normal(0, C.BLANK_NOISE_SIGMA, (500, 784)), 0, 1)
    assert data.is_blank(noise).all()
    cells = np.vstack([X[:41], noise[:40]])
    assert np.array_equal(data.split_mosaic(data.build_mosaic(cells)), cells)


def test_normal_split_has_no_overlap_in_sizes_and_no_zero_digits(mnist):
    assert all(mnist[f"d_{s}"].min() == 1 and mnist[f"d_{s}"].max() == 9 for s in ("train", "val", "test"))
    assert len(mnist["d_train"]) + len(mnist["d_val"]) == 54077


def test_normal_pipeline_recovers_one_misread(mnist, mlp):
    model, T = mlp
    pools = G.build_pools(mnist, model, T)
    ok = 0
    for i, p in enumerate(G.generate_puzzle_set(30, 7, 12, cache=False)):
        inst = G.make_instance(p["puzzle"], 1, pools, random.Random(i))
        read = I.read_mosaic(G.render_mosaic(inst["image_idx"], mnist["X_test"], i), model, T)
        res = I.solve_read(read, goal="unique")
        assert res.status == "solved"
        ok += res.solution == p["solution"]
    assert ok >= 8


def test_edge_generation_is_deterministic_in_the_seed():
    a = G.generate_puzzle_set(28, 11, 2, cache=False)
    assert a == G.generate_puzzle_set(28, 11, 2, cache=False)
    assert a != G.generate_puzzle_set(28, 12, 2, cache=False)


def test_edge_zero_misreads_reads_the_puzzle_exactly_and_needs_no_correction(mnist, mlp):
    model, T = mlp
    pools = G.build_pools(mnist, model, T)
    p = G.generate_puzzle_set(30, 5, 1, cache=False)[0]
    inst = G.make_instance(p["puzzle"], 0, pools, random.Random(1))
    read = I.read_mosaic(G.render_mosaic(inst["image_idx"], mnist["X_test"], 1), model, T)
    assert read.grid == p["puzzle"] and (read.blank == (np.array(p["puzzle"]) == 0)).all()
    res = I.solve_read(read)
    assert res.status == "solved" and res.corrections == [] and not res.ac3_conflict


def test_edge_injected_misreads_are_exactly_as_many_as_requested(mnist, mlp):
    model, T = mlp
    pools = G.build_pools(mnist, model, T)
    p = G.generate_puzzle_set(30, 6, 1, cache=False)[0]
    for m in range(5):
        inst = G.make_instance(p["puzzle"], m, pools, random.Random(m))
        read = I.read_mosaic(G.render_mosaic(inst["image_idx"], mnist["X_test"], m), model, T)
        assert sum(r != q for r, q in zip(read.grid, p["puzzle"])) == m


def test_impossible_unreadable_mosaic_reports_least_confident_cells(mnist, mlp):
    model, T = mlp
    cells = np.clip(np.random.default_rng(3).normal(0, C.BLANK_NOISE_SIGMA, (81, 784)), 0, 1)
    for i in (0, 1, 2):
        cells[i] = mnist["X_test"][np.where(mnist["d_test"] == 1)[0][0]]
    res = I.solve_mosaic(data.build_mosaic(cells), model, T, mode="nn", algo="astar", max_corrections=1)
    assert res.status == "unreadable" and "UNREADABLE" in res.message and res.least_confident
    assert res.ac3_conflict
