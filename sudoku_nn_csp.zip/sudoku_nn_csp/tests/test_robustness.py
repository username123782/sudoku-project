import random
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

from helpers import PUZZLE, SOLUTION, synthetic_probs
from sudoku_rs import config as C
from sudoku_rs import csp, search
from sudoku_rs import generator as G
from sudoku_rs import integration as I

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("bad", [[0] * 80, [10] + [0] * 80, [-1] + [0] * 80, [1.5] + [0] * 80, ["a"] + [0] * 80])
def test_edge_csp_rejects_malformed_puzzles_with_a_clear_message(bad):
    with pytest.raises(ValueError, match="81 cells|integer 0-9"):
        csp.solve(bad)
    with pytest.raises(ValueError):
        csp.ac3_conflict(bad)


def test_edge_search_rejects_unknown_options():
    probs = synthetic_probs(PUZZLE)
    with pytest.raises(ValueError, match="algo"):
        search.best_first(search.CorrectionProblem(PUZZLE, probs), "dijkstra")
    with pytest.raises(ValueError, match="goal"):
        search.CorrectionProblem(PUZZLE, probs, goal="uniq")
    with pytest.raises(ValueError, match="max_corrections"):
        search.CorrectionProblem(PUZZLE, probs, max_corrections=-1)


def test_edge_pipeline_rejects_unknown_mode_and_wrong_mosaic_shape():
    read = I.ReadResult(PUZZLE, synthetic_probs(PUZZLE), np.zeros(81, bool))
    with pytest.raises(ValueError, match="mode"):
        I.solve_read(read, mode="NN")
    with pytest.raises(ValueError, match="252x252"):
        I.read_mosaic(np.zeros((28, 28)), None)


def test_edge_random_baseline_with_no_corrections_allowed_or_very_few_givens():
    grid = [0] * 81
    grid[0] = grid[1] = 5
    probs = np.zeros((81, 9))
    probs[0, 4] = probs[1, 4] = 0.6
    probs[0, 2] = probs[1, 2] = 0.4
    none_allowed = search.CorrectionProblem(grid, probs, max_corrections=0)
    assert search.random_search(none_allowed, random.Random(1), 20).status == "unreadable"
    few = search.CorrectionProblem(grid, probs, max_corrections=3)
    assert search.random_search(few, random.Random(1), 200).status in ("solved", "unreadable")


def test_edge_generator_rejects_impossible_requests():
    with pytest.raises(ValueError, match="17"):
        G.make_puzzle(SOLUTION, 16, random.Random(1))
    with pytest.raises(ValueError, match="17"):
        G.make_puzzle(SOLUTION, 82, random.Random(1))
    pools = G.Pools({k: np.array([0]) for k in range(1, 10)}, {k: np.array([0]) for k in range(1, 10)}, None)
    with pytest.raises(ValueError, match="cannot inject"):
        G.make_instance(PUZZLE, 99, pools, random.Random(1))


def test_edge_quick_experiment_runs_write_to_a_separate_folder(monkeypatch):
    import run_experiments as RX
    monkeypatch.setattr(C, "TABLES", C.TABLES)
    monkeypatch.setattr(C, "FIGS", C.FIGS)
    out = RX.configure_outputs(True)
    assert out == C.RESULTS / "quick" and C.TABLES == out / "tables" and C.FIGS == out / "figures"
    assert RX.configure_outputs(False) == C.RESULTS and C.TABLES == C.RESULTS / "tables"


def run_demo(out, *args):
    return subprocess.run([sys.executable, "run_demo.py", "--out", str(out), *args], cwd=ROOT,
                          capture_output=True, text=True, timeout=300)


def test_edge_demo_runs_with_zero_misreads(mnist, mlp, tmp_path):
    r = run_demo(tmp_path, "--misreads", "0")
    assert r.returncode == 0 and "matches ground truth: True" in r.stdout and (tmp_path / "demo_overview.png").exists()


def test_edge_demo_rejects_too_few_givens_with_a_clear_error(mnist, mlp, tmp_path):
    r = run_demo(tmp_path, "--givens", "12")
    assert r.returncode != 0 and "17..81" in r.stderr and "Traceback" not in r.stderr


def test_impossible_demo_reports_unreadable_instead_of_crashing(mnist, mlp, tmp_path):
    r = run_demo(tmp_path, "--seed", "1", "--misreads", "4", "--no-auto", "--goal", "unique")
    assert r.returncode == 0 and "UNREADABLE" in r.stdout and "Traceback" not in r.stderr
    assert (tmp_path / "demo_overview.png").exists()


def _python_files():
    skip = {".venv", ".git", "__pycache__", "node_modules"}
    return [p for p in ROOT.rglob("*.py") if not skip & set(p.relative_to(ROOT).parts)]


def test_normal_scripts_have_no_unix_shebang():
    assert [p.name for p in _python_files() if p.read_text(encoding="utf-8").startswith("#!")] == []


def test_normal_all_text_file_io_declares_utf_8():
    import ast
    offenders = []
    for p in _python_files():
        for node in ast.walk(ast.parse(p.read_text(encoding="utf-8"))):
            if not isinstance(node, ast.Call):
                continue
            f = node.func
            has_enc = any(k.arg == "encoding" for k in node.keywords)
            if isinstance(f, ast.Attribute) and f.attr in ("read_text", "write_text") and not has_enc:
                offenders.append(f"{p.name}:{node.lineno}")
            if isinstance(f, ast.Name) and f.id == "open":
                mode = node.args[1].value if len(node.args) > 1 and isinstance(node.args[1], ast.Constant) else "r"
                if "b" not in mode and not has_enc:
                    offenders.append(f"{p.name}:{node.lineno}")
    assert offenders == []


def test_edge_missing_model_gives_a_clear_message(tmp_path):
    from sudoku_rs import nn
    with pytest.raises(FileNotFoundError, match="train_nn.py"):
        nn.MLP.load(tmp_path / "nope.npz")


def test_normal_code_has_no_comments_or_docstrings():
    import ast
    import io
    import tokenize
    found = []
    for p in _python_files():
        src = p.read_text(encoding="utf-8")
        found += [f"{p.name}:{t.start[0]}" for t in tokenize.generate_tokens(io.StringIO(src).readline) if t.type == tokenize.COMMENT]
        for node in ast.walk(ast.parse(src)):
            if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and ast.get_docstring(node, clean=False) is not None:
                found.append(f"{p.name}:{getattr(node, 'lineno', 1)} docstring")
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                found.append(f"{p.name}:{node.lineno} string statement")
    lines = (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines()
    import re
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    blocks = re.findall(r"```[a-z]*\n(.*?)```", readme, re.S)
    shell_comments = [ln for b in blocks for ln in b.splitlines() if ln.lstrip().startswith("#") or " #" in ln]
    assert found == [] and shell_comments == [] and not any(line.lstrip().startswith("#") for line in lines)
