# 5-minute live demo (10-minute talk + demo)

Prepare once: `python make_data.py && python train_nn.py` (about 40 seconds). Then everything below runs in seconds.
The numbers below are for the default instance (seed 4, found automatically); they are also in `results/demo/demo_summary.json`.

| min | command / action | what to point at |
|---|---|---|
| 0:00 | `python run_demo.py` | Sections 1-2: the handwritten mosaic (open `results/demo/input_mosaic.png`) and the NN reading with the two misreads marked `*` (r9c7 read 3, r1c2 read 8) |
| 1:00 | same output, Section 3 | AC-3 empties a domain: two 8s in row 1 and two 3s in row 9, so the first reading is impossible |
| 1:30 | Section 4 (**search trace**) | UCS tries the first reading (cost 0), then the cheapest single changes, then pairs; the 10th node passes the CSP test (cost 2.371). A* needs 5 expansions, Greedy 65 |
| 2:30 | Section 5 (**CSP pruning**) | BT 59,927 -> BT+FC 17,019 -> BT+FC+AC-3 55 assignments; AC-3 shrinks the domains 521 -> 81 before search. This instance is a best case for AC-3: the Experiment 2 average at 25 givens is 1.6x fewer assignments than FC alone (14,785 -> 9,343) |
| 3:30 | Section 6 (**NN on vs off**) | NN-guided correction recovers 93% of 30 puzzles (2 misreads); no correction and random correction recover 0% |
| 4:15 | open `results/demo/demo_overview.png` | the whole chain in one picture |
| 4:45 | `python run_demo.py --seed 12 --misreads 3` | change the seed live (custom runs write to `results/demo_custom/`, the default files stay untouched). Then show the unreadable case: `python run_demo.py --seed 1 --misreads 4 --no-auto --goal unique` (4 misreads > 3 allowed corrections -> "UNREADABLE" with the least confident cells, no guess) |

Backup if something breaks: `results/demo/demo_overview.png`, `results/experiments_log_search.txt` and
`results/experiments_log_csp.txt` are already in the repo.
