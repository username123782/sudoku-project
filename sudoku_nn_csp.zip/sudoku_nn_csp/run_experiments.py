import argparse
import json
import time

from sudoku_rs import config as C
from sudoku_rs import eval as E


def configure_outputs(quick: bool):
    out = C.RESULTS / "quick" if quick else C.RESULTS
    C.TABLES, C.FIGS = out / "tables", out / "figures"
    return out


def main():
    C.safe_console()
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--puzzles", type=int, default=100, help="puzzles per seed per condition")
    ap.add_argument("--stage", default="all", choices=["all", "search", "csp"],
                    help="search = classifier report + Exp 1 + Exp 3; csp = Exp 2")
    args = ap.parse_args()
    seeds = C.EXPERIMENT_SEEDS[:2] if args.quick else C.EXPERIMENT_SEEDS
    n = 10 if args.quick else args.puzzles
    out = configure_outputs(args.quick)
    C.TABLES.mkdir(parents=True, exist_ok=True)
    C.FIGS.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    if args.stage in ("all", "search"):
        print("classifier report + hard-digit pool ...")
        E.classifier_report()
        print(json.dumps(E.hard_pool_report(), indent=1))
        print(f"Exp 1 + 3 (search / NN effect): seeds={seeds} puzzles/seed={n} ...", flush=True)
        df = E.run_search_experiments(seeds, n, log_path=C.TABLES / "correction_logs.jsonl")
        df.to_csv(C.TABLES / "raw_search_runs.csv", index=False)
        t1, t3 = E.summarize_search(df)
        opt = E.optimality_check(df)
        (out / "optimality_check.json").write_text(json.dumps(opt, indent=1), encoding="utf-8")
        print(t1.to_markdown(index=False), "\n", json.dumps(opt, indent=1), "\n", t3.to_markdown(index=False))
    if args.stage in ("all", "csp"):
        print(f"Exp 2 (CSP): seeds={seeds} puzzles/seed={n} ...", flush=True)
        dfc = E.run_csp_experiments(seeds, n)
        dfc.to_csv(C.TABLES / "raw_csp_runs.csv", index=False)
        print(E.summarize_csp(dfc).to_markdown(index=False))
    print(f"done in {time.time() - t0:.0f}s -> {C.TABLES}, {C.FIGS}")


if __name__ == "__main__":
    main()
