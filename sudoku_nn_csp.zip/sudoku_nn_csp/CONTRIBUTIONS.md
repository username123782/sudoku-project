# Individual contribution statement (max 200 words each)

> **Draft - every team member must edit their own statement so it describes what they personally did.**
> Keep each statement under 200 words and keep the git log (`GIT_LOG.txt`) consistent with it.

## [Your name] - [student ID]

**What I did:** [Name the parts you personally wrote, ran, tested or reviewed, e.g. data pipeline (`data.py`,
`make_data.py`), neural network (`nn.py`, `train_nn.py`), CSP (`csp.py`), search (`search.py`), integration, experiments
(`eval.py`), tests, report, slides. Say which experiments you re-ran and which numbers you checked.]

**What I changed or decided:** [Any parameter, design choice or fix that is yours: e.g. number of candidate cells,
hard-digit rule, goal test, plots.]

**What I can explain without notes:** [e.g. why A* with the conflict heuristic is admissible; why FC/AC-3 matter less
under MRV ordering.]

**Use of AI assistance (disclosure):** The first version of the code, tests, report and slides in this repository was
generated with Claude (Anthropic) from the project brief (P7). [Describe what you verified yourself: commands re-run,
results checked, parts rewritten.]
