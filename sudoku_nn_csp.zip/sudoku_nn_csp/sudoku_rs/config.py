import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROC = ROOT / "data" / "processed"
DATA_GEN = ROOT / "data" / "generated"
MODELS = ROOT / "models"
RESULTS = ROOT / "results"
FIGS = RESULTS / "figures"
TABLES = RESULTS / "tables"

MASTER_SEED = 2026
EXPERIMENT_SEEDS = [0, 1, 2, 3, 4]

BLANK_MIN_INK = 10
BLANK_NOISE_SIGMA = 0.02
HARD_CONF_MAX = 0.90
HARD_TOPK = 3

MAX_CORRECTIONS = 3
N_CANDIDATE_CELLS = 12
K_ALTERNATIVES = 2
MAX_EXPANSIONS = 5000


def safe_console():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="replace")
