from __future__ import annotations

import heapq
import math
import time
from dataclasses import dataclass, field

import numpy as np

from . import config as C
from . import csp

ALT_MIN_PROB = 1e-4


@dataclass
class SearchCounters:
    generated: int = 0
    expanded: int = 0
    goal_tests: int = 0
    csp_calls: int = 0
    csp: csp.CSPCounters = field(default_factory=csp.CSPCounters)

    def as_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "csp"}
        d.update({f"csp_{k}": v for k, v in self.csp.as_dict().items()})
        return d


@dataclass
class SearchResult:
    status: str
    state: tuple | None = None
    cost: float = math.inf
    solution: list | None = None
    corrections: list = field(default_factory=list)
    counters: SearchCounters = field(default_factory=SearchCounters)
    trace: list = field(default_factory=list)
    message: str = ""
    elapsed: float = 0.0


class CorrectionProblem:
    def __init__(self, read_grid, probs, max_corrections=C.MAX_CORRECTIONS, n_cand=C.N_CANDIDATE_CELLS,
                 k_alt=C.K_ALTERNATIVES, goal="solvable", csp_cfg=None):
        if goal not in ("solvable", "unique"):
            raise ValueError(f"goal must be 'solvable' or 'unique', got {goal!r}")
        if max_corrections < 0:
            raise ValueError("max_corrections must be >= 0")
        csp.check_grid(read_grid)
        self.read_grid = list(read_grid)
        self.probs = np.asarray(probs)
        self.max_corrections, self.goal = max_corrections, goal
        self.csp_cfg = csp_cfg or dict(use_fc=True, use_ac3=True, var_order="mrv")
        self.givens = [i for i, v in enumerate(self.read_grid) if v]
        self.conf = {i: float(self.probs[i].max()) for i in self.givens}
        self.cand = sorted(self.givens, key=lambda i: (self.conf[i], i))[:n_cand]
        self.cand_pos = {cell: j for j, cell in enumerate(self.cand)}
        self.alts = []
        for i in self.cand:
            p, read = np.clip(self.probs[i], 1e-9, 1.0), self.read_grid[i]
            order = [int(d) for d in np.argsort(-p) + 1 if d != read and p[d - 1] >= ALT_MIN_PROB][:k_alt]
            self.alts.append([(d, max(0.0, math.log(p[read - 1]) - math.log(p[d - 1]))) for d in order])
        self.min_cost = [a[0][1] if a else math.inf for a in self.alts]

    def apply(self, state) -> list:
        g = self.read_grid[:]
        for j, a in state:
            g[self.cand[j]] = self.alts[j][a][0]
        return g

    def state_cost(self, state) -> float:
        return sum(self.alts[j][a][1] for j, a in state)

    def successors(self, state):
        if len(state) >= self.max_corrections:
            return
        for j in range((state[-1][0] + 1) if state else 0, len(self.cand)):
            for a, (_, cost) in enumerate(self.alts[j]):
                yield state + ((j, a),), cost

    def describe(self, state) -> list:
        out = []
        for j, a in state:
            cell = self.cand[j]
            out.append({"cell": cell, "row": cell // 9 + 1, "col": cell % 9 + 1, "read": self.read_grid[cell],
                        "new": self.alts[j][a][0], "cost": round(self.alts[j][a][1], 4)})
        return out

    def least_confident(self, k: int = 5) -> list:
        return [(c // 9 + 1, c % 9 + 1, self.conf[c]) for c in sorted(self.givens, key=lambda c: self.conf[c])[:k]]

    def heuristic(self, state, grid=None) -> float:
        grid = grid or self.apply(state)
        pairs = csp.conflict_pairs(grid)
        if not pairs:
            return 0.0
        changed = {j for j, _ in state}

        def w(cell):
            j = self.cand_pos.get(cell)
            return math.inf if j is None or j in changed else self.min_cost[j]

        used, h = set(), 0.0
        for u, v in pairs:
            if u in used or v in used:
                continue
            wt = min(w(u), w(v))
            if wt == math.inf:
                return math.inf
            used.update((u, v))
            h += wt
        return h

    def goal_test_grid(self, grid, counters: SearchCounters):
        counters.goal_tests += 1
        if csp.conflict_pairs(grid):
            return False, None
        counters.csp_calls += 1
        res = csp.solve(grid, max_solutions=2 if self.goal == "unique" else 1, **self.csp_cfg)
        counters.csp.add(res.counters)
        ok = res.solved and (self.goal != "unique" or len(res.solutions) == 1)
        return ok, (res.solutions[0] if res.solved else None)

    def goal_test(self, state, counters):
        return self.goal_test_grid(self.apply(state), counters)

    def unreadable_message(self) -> str:
        cells = ", ".join(f"r{r}c{c} (conf {p:.2f})" for r, c, p in self.least_confident())
        return (f"UNREADABLE: no set of at most {self.max_corrections} corrections among the "
                f"{len(self.cand)} least-confident cells gives a {self.goal} puzzle. "
                f"Least confident cells: {cells}.")


def best_first(problem: CorrectionProblem, algo: str = "ucs", max_expansions: int = C.MAX_EXPANSIONS,
               trace_limit: int = 0) -> SearchResult:
    if algo not in ("ucs", "greedy", "astar"):
        raise ValueError(f"algo must be 'ucs', 'greedy' or 'astar', got {algo!r}")
    t0, cnt, trace = time.perf_counter(), SearchCounters(), []

    def key(g, h):
        return (g,) if algo == "ucs" else ((h, g) if algo == "greedy" else (g + h, h))

    root = ()
    h0 = 0.0 if algo == "ucs" else problem.heuristic(root)
    heap, tie = [(key(0.0, h0), 0, root, 0.0)], 1
    cnt.generated = 1
    while heap:
        k, _, state, g = heapq.heappop(heap)
        cnt.expanded += 1
        ok, sol = problem.goal_test(state, cnt)
        if len(trace) < trace_limit:
            trace.append({"order": cnt.expanded, "corrections": [(c["row"], c["col"], c["read"], c["new"])
                          for c in problem.describe(state)], "g": g, "f": k[0], "goal": ok})
        if ok:
            return SearchResult("solved", state, g, sol, problem.describe(state), cnt, trace,
                                "solved", time.perf_counter() - t0)
        if cnt.expanded >= max_expansions:
            break
        for child, c in problem.successors(state):
            cnt.generated += 1
            h = 0.0 if algo == "ucs" else problem.heuristic(child)
            if h == math.inf:
                continue
            heapq.heappush(heap, (key(g + c, h), tie, child, g + c))
            tie += 1
    return SearchResult("unreadable", counters=cnt, trace=trace, message=problem.unreadable_message(),
                        elapsed=time.perf_counter() - t0)


def no_correction(problem: CorrectionProblem) -> SearchResult:
    t0, cnt = time.perf_counter(), SearchCounters()
    cnt.generated = cnt.expanded = 1
    ok, sol = problem.goal_test((), cnt)
    if ok:
        return SearchResult("solved", (), 0.0, sol, [], cnt, [], "solved", time.perf_counter() - t0)
    return SearchResult("unreadable", counters=cnt, message=problem.unreadable_message(),
                        elapsed=time.perf_counter() - t0)


def random_search(problem: CorrectionProblem, rng, tries: int = 300) -> SearchResult:
    t0, cnt = time.perf_counter(), SearchCounters()
    cnt.generated = cnt.expanded = 1
    ok, sol = problem.goal_test_grid(problem.read_grid, cnt)
    if ok:
        return SearchResult("solved", (), 0.0, sol, [], cnt, [], "solved", time.perf_counter() - t0)
    limit = min(problem.max_corrections, len(problem.givens))
    for _ in range(tries if limit >= 1 else 0):
        m = rng.randint(1, limit)
        cells = rng.sample(problem.givens, m)
        grid = problem.read_grid[:]
        for c in cells:
            grid[c] = rng.choice([d for d in range(1, 10) if d != grid[c]])
        cnt.generated += 1
        cnt.expanded += 1
        ok, sol = problem.goal_test_grid(grid, cnt)
        if ok:
            corr = [{"cell": c, "row": c // 9 + 1, "col": c % 9 + 1, "read": problem.read_grid[c], "new": grid[c],
                     "cost": None} for c in cells]
            return SearchResult("solved", None, math.nan, sol, corr, cnt, [], "solved", time.perf_counter() - t0)
    return SearchResult("unreadable", counters=cnt, message=problem.unreadable_message(),
                        elapsed=time.perf_counter() - t0)


def brute_force_optimum(problem: CorrectionProblem):
    best = (math.inf, None)
    cnt = SearchCounters()
    stack = [()]
    while stack:
        s = stack.pop()
        if problem.state_cost(s) < best[0] and problem.goal_test(s, cnt)[0]:
            best = (problem.state_cost(s), s)
        stack.extend(child for child, _ in problem.successors(s))
    return best
