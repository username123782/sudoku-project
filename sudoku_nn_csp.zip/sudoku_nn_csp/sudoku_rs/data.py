from __future__ import annotations

import gzip
import hashlib
import json
import urllib.request
from pathlib import Path

import numpy as np

from . import config as C

MNIST_FILES = {
    "train_images": ("train-images-idx3-ubyte.gz", "f68b3c2dcbeaaa9fbdd348bbdeb94873"),
    "train_labels": ("train-labels-idx1-ubyte.gz", "d53e105ee54ea40749a09fcbcd1e9432"),
    "test_images": ("t10k-images-idx3-ubyte.gz", "9fb629c4189551a2d022fa330f9573f3"),
    "test_labels": ("t10k-labels-idx1-ubyte.gz", "ec29112dd5afa0611ce80d1b7f02629c"),
}
MIRRORS = [
    "https://ossci-datasets.s3.amazonaws.com/mnist",
    "https://github.com/golbin/TensorFlow-MNIST/raw/master/mnist/data",
    "http://yann.lecun.com/exdb/mnist",
]
PROCESSED_FILE = "mnist_1to9.npz"


def _md5(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download_all(raw_dir: Path = C.DATA_RAW, verbose: bool = True) -> dict:
    raw_dir.mkdir(parents=True, exist_ok=True)
    sums = {}
    for key, (fname, md5) in MNIST_FILES.items():
        path = raw_dir / fname
        if path.exists() and _md5(path) == md5:
            sums[fname] = md5
            continue
        for base in MIRRORS:
            url = f"{base}/{fname}"
            try:
                if verbose:
                    print(f"  downloading {url}")
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=30) as r, open(path, "wb") as out:
                    out.write(r.read())
                if _md5(path) == md5:
                    sums[fname] = md5
                    break
                print("  checksum mismatch, trying next mirror")
            except Exception as exc:
                print(f"  failed ({exc.__class__.__name__}), trying next mirror")
        else:
            raise RuntimeError(f"could not download a valid copy of {fname}; place it in {raw_dir}")
    return sums


def read_idx_images(path: Path) -> np.ndarray:
    with gzip.open(path, "rb") as f:
        buf = f.read()
    magic, n, rows, cols = np.frombuffer(buf[:16], dtype=">i4")
    assert magic == 2051, "not an idx image file"
    return np.frombuffer(buf, dtype=np.uint8, offset=16).reshape(n, rows * cols)


def read_idx_labels(path: Path) -> np.ndarray:
    with gzip.open(path, "rb") as f:
        buf = f.read()
    magic, n = np.frombuffer(buf[:8], dtype=">i4")
    assert magic == 2049, "not an idx label file"
    return np.frombuffer(buf, dtype=np.uint8, offset=8)


def preprocess(raw_dir: Path = C.DATA_RAW, out_dir: Path = C.DATA_PROC, seed: int = C.MASTER_SEED) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    X = read_idx_images(raw_dir / MNIST_FILES["train_images"][0])
    y = read_idx_labels(raw_dir / MNIST_FILES["train_labels"][0])
    Xte = read_idx_images(raw_dir / MNIST_FILES["test_images"][0])
    yte = read_idx_labels(raw_dir / MNIST_FILES["test_labels"][0])
    assert X.shape == (60000, 784) and Xte.shape == (10000, 784)

    perm = np.random.default_rng(seed).permutation(60000)
    tr, va = perm[:50000], perm[50000:]
    parts = {"train": (X[tr], y[tr]), "val": (X[va], y[va]), "test": (Xte, yte)}
    arrays, counts = {}, {}
    for name, (xs, ys) in parts.items():
        keep = ys != 0
        arrays[f"X_{name}"], arrays[f"d_{name}"] = xs[keep], ys[keep]
        counts[name] = {int(d): int((ys[keep] == d).sum()) for d in range(1, 10)}
    np.savez_compressed(out_dir / PROCESSED_FILE, **arrays)

    ink_min = int(min((arrays[f"X_{s}"] > 127).sum(1).min() for s in parts))
    manifest = {
        "seed": seed,
        "split": "50,000 train / 10,000 validation from the 60,000 training images; 10,000 official test images",
        "sizes_after_dropping_zero": {k: int(len(arrays[f"d_{k}"])) for k in parts},
        "per_digit_counts": counts,
        "min_pixels_above_0.5_in_any_digit_image": ink_min,
        "blank_rule": f"blank if fewer than {C.BLANK_MIN_INK} pixels exceed 0.5",
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def load_processed(path: Path | None = None, auto_prepare: bool = False) -> dict:
    default = path is None
    path = path or (C.DATA_PROC / PROCESSED_FILE)
    if not path.exists():
        if not (auto_prepare and default):
            raise FileNotFoundError(f"{path} missing - run `python make_data.py` first")
        print("processed MNIST data not found - running the make_data.py steps (download of about 11 MB) ...")
        download_all()
        preprocess()
    z = np.load(path)
    out = {}
    for s in ("train", "val", "test"):
        out[f"X_{s}"] = z[f"X_{s}"].astype(np.float32) / 255.0
        out[f"d_{s}"] = z[f"d_{s}"].astype(np.int64)
        out[f"y_{s}"] = out[f"d_{s}"] - 1
    return out


def is_blank(cells: np.ndarray) -> np.ndarray:
    cells = np.atleast_2d(cells)
    return (cells > 0.5).sum(axis=1) < C.BLANK_MIN_INK


def build_mosaic(cells: np.ndarray) -> np.ndarray:
    return cells.reshape(9, 9, 28, 28).transpose(0, 2, 1, 3).reshape(252, 252)


def split_mosaic(mosaic: np.ndarray) -> np.ndarray:
    return mosaic.reshape(9, 28, 9, 28).transpose(0, 2, 1, 3).reshape(81, 784)
