from __future__ import annotations

import argparse
import json
import random
import warnings
from dataclasses import dataclass

import numpy as np

from . import config as C
from . import csp, data


def random_solution(rng: random.Random) -> list:
    return csp.solve([0] * 81, use_fc=True, use_ac3=False, var_order="mrv", rng=rng).solutions[0]


def make_puzzle(solution: list, n_givens: int, rng: random.Random, max_attempts: int = 60):
    if not 17 <= n_givens <= 81:
        raise ValueError(f"n_givens must be in 17..81 (no Sudoku with fewer than 17 givens has a unique solution), got {n_givens}")
    best = None
    for _ in range(max_attempts):
        order = list(range(81))
        rng.shuffle(order)
        p, g = list(solution), 81
        for cell in order:
            if g <= n_givens:
                break
            keep = p[cell]
            p[cell] = 0
            if csp.count_solutions(p, 2) == 1:
                g -= 1
            else:
                p[cell] = keep
        if best is None or g < best[1]:
            best = (p[:], g)
        if g <= n_givens:
            break
    if best[1] > n_givens:
        warnings.warn(f"could only reach {best[1]} givens (requested {n_givens}) while keeping a unique solution")
    return best


def generate_puzzle_set(n_givens: int, seed: int, count: int, cache: bool = True) -> list:
    path = C.DATA_GEN / f"puzzles_g{n_givens}_s{seed}_n{count}.json"
    if cache and path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    out = []
    for i in range(count):
        rng = random.Random(f"puzzle-{n_givens}-{seed}-{i}")
        sol = random_solution(rng)
        puz, g = make_puzzle(sol, n_givens, rng)
        out.append({"puzzle": puz, "solution": sol, "givens": g})
    if cache:
        C.DATA_GEN.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(out), encoding="utf-8")
    return out


@dataclass
class Pools:
    clean: dict
    hard: dict
    probs: np.ndarray


def build_pools(d: dict, model, T: float) -> Pools:
    probs = model.predict_proba(d["X_test"], T)
    y, pred = d["y_test"], probs.argmax(1)
    topk = np.argsort(-probs, axis=1)[:, :C.HARD_TOPK]
    true_in_topk = (topk == y[:, None]).any(axis=1)
    hard_mask = (pred != y) & true_in_topk & (probs.max(1) <= C.HARD_CONF_MAX)
    clean = {k: np.where((y == k - 1) & (pred == y))[0] for k in range(1, 10)}
    hard = {k: np.where((y == k - 1) & hard_mask)[0] for k in range(1, 10)}
    return Pools(clean, hard, probs)


def make_instance(puzzle: list, n_misreads: int, pools: Pools, rng: random.Random) -> dict:
    givens = [i for i, v in enumerate(puzzle) if v]
    eligible = [i for i in givens if len(pools.hard[puzzle[i]]) > 0]
    if not 0 <= n_misreads <= len(eligible):
        raise ValueError(f"cannot inject {n_misreads} misreads: only {len(eligible)} givens have a hard image available")
    injected = sorted(rng.sample(eligible, n_misreads)) if n_misreads else []
    idx = [-1] * 81
    for i in givens:
        pool = pools.hard[puzzle[i]] if i in injected else pools.clean[puzzle[i]]
        idx[i] = int(pool[rng.randrange(len(pool))])
    return {"image_idx": idx, "injected": injected}


def render_mosaic(image_idx: list, X_test: np.ndarray, seed: int) -> np.ndarray:
    nrng = np.random.default_rng(seed)
    cells = np.clip(nrng.normal(0, C.BLANK_NOISE_SIGMA, (81, 784)), 0, 1).astype(np.float32)
    for i, k in enumerate(image_idx):
        if k >= 0:
            cells[i] = X_test[k]
    return data.build_mosaic(cells)


def main():
    from . import nn
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--givens", type=int, default=30)
    ap.add_argument("--misreads", type=int, default=2)
    ap.add_argument("--out", default=str(C.RESULTS / "sample_instance"))
    a = ap.parse_args()
    d = data.load_processed(auto_prepare=True)
    model, T = nn.MLP.load(C.MODELS / "mlp.npz")
    pools = build_pools(d, model, T)
    base = generate_puzzle_set(a.givens, a.seed, 1)[0]
    inst = make_instance(base["puzzle"], a.misreads, pools, random.Random(f"inst-{a.seed}"))
    mosaic = render_mosaic(inst["image_idx"], d["X_test"], a.seed)
    np.savez(a.out + ".npz", mosaic=mosaic, puzzle=base["puzzle"], solution=base["solution"],
             injected=inst["injected"])
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.imsave(a.out + ".png", mosaic, cmap="gray")
    print(f"saved {a.out}.npz/.png  givens={base['givens']} injected cells={inst['injected']}")


if __name__ == "__main__":
    main()
