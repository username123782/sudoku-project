from __future__ import annotations

import numbers
import time
from collections import deque
from dataclasses import dataclass, field

ROW = [i // 9 for i in range(81)]
COL = [i % 9 for i in range(81)]
BOX = [(i // 27) * 3 + (i % 9) // 3 for i in range(81)]
UNITS = ([[r * 9 + c for c in range(9)] for r in range(9)]
         + [[r * 9 + c for r in range(9)] for c in range(9)]
         + [[(br * 3 + r) * 9 + bc * 3 + c for r in range(3) for c in range(3)]
            for br in range(3) for bc in range(3)])
PEERS = [[j for j in range(81) if j != i and (ROW[j] == ROW[i] or COL[j] == COL[i] or BOX[j] == BOX[i])]
         for i in range(81)]
ALL = 0x1FF
POPCNT = [bin(m).count("1") for m in range(512)]
DIGITS = [[d for d in range(1, 10) if m >> (d - 1) & 1] for m in range(512)]


@dataclass
class CSPCounters:
    assignments: int = 0
    backtracks: int = 0
    fc_prunes: int = 0
    ac3_revisions: int = 0
    ac3_prunes: int = 0

    def as_dict(self) -> dict:
        return dict(self.__dict__)

    def add(self, other: "CSPCounters") -> None:
        for k, v in other.__dict__.items():
            setattr(self, k, getattr(self, k) + v)


@dataclass
class SolveResult:
    status: str
    solutions: list = field(default_factory=list)
    counters: CSPCounters = field(default_factory=CSPCounters)
    elapsed: float = 0.0
    message: str = ""

    @property
    def solved(self) -> bool:
        return self.status == "solved"


class _Limit(Exception):
    pass


def ac3(dom: list, counters: CSPCounters) -> bool:
    queue = deque((x, y) for x in range(81) for y in PEERS[x])
    while queue:
        x, y = queue.popleft()
        counters.ac3_revisions += 1
        dy = dom[y]
        if POPCNT[dy] == 1 and dom[x] & dy:
            dom[x] &= ~dy
            counters.ac3_prunes += 1
            if dom[x] == 0:
                return False
            for z in PEERS[x]:
                if z != y:
                    queue.append((z, x))
    return True


def check_grid(grid) -> None:
    if len(grid) != 81:
        raise ValueError(f"a Sudoku has 81 cells (row-major, 0 = empty), got {len(grid)}")
    for i, v in enumerate(grid):
        if not isinstance(v, numbers.Integral) or not 0 <= v <= 9:
            raise ValueError(f"cell {i} holds {v!r}; every cell must be an integer 0-9 (0 = empty)")


def initial_domains(grid) -> list:
    check_grid(grid)
    return [(1 << (v - 1)) if v else ALL for v in grid]


def ac3_conflict(grid) -> bool:
    return not ac3(initial_domains(grid), CSPCounters())


def conflict_pairs(grid) -> list:
    pairs = []
    for unit in UNITS:
        seen = {}
        for cell in unit:
            v = grid[cell]
            if v:
                if v in seen:
                    pairs.extend((o, cell) for o in seen[v])
                    seen[v].append(cell)
                else:
                    seen[v] = [cell]
    return pairs


def domain_sizes(grid, use_ac3: bool = True) -> list:
    dom = initial_domains(grid)
    if use_ac3:
        ac3(dom, CSPCounters())
    return [POPCNT[m] for m in dom]


def solve(puzzle, use_fc: bool = True, use_ac3: bool = True, var_order: str = "mrv",
          max_solutions: int = 1, node_limit: int | None = None, rng=None) -> SolveResult:
    t0 = time.perf_counter()
    check_grid(puzzle)
    c = CSPCounters()
    grid = [int(v) for v in puzzle]
    dom = initial_domains(grid)

    def finish(status, sols, msg):
        return SolveResult(status, sols, c, time.perf_counter() - t0, msg)

    if use_ac3 and not ac3(dom, c):
        return finish("no_solution", [], "NO SOLUTION: AC-3 emptied a domain - the givens contradict "
                                         "the Sudoku rules (e.g. two equal digits in one row/column/box).")
    rows, cols, boxes = [0] * 9, [0] * 9, [0] * 9
    for i, v in enumerate(grid):
        if v:
            bit = 1 << (v - 1)
            if (rows[ROW[i]] | cols[COL[i]] | boxes[BOX[i]]) & bit:
                return finish("no_solution", [], "NO SOLUTION: two equal digits share a row, column or box.")
            rows[ROW[i]] |= bit
            cols[COL[i]] |= bit
            boxes[BOX[i]] |= bit
    if use_fc:
        for i, v in enumerate(grid):
            if v:
                bit = 1 << (v - 1)
                for p in PEERS[i]:
                    if grid[p] == 0 and dom[p] & bit:
                        dom[p] &= ~bit
                        c.fc_prunes += 1
                        if dom[p] == 0:
                            return finish("no_solution", [], "NO SOLUTION: forward checking emptied a domain.")
    empties = [i for i in range(81) if grid[i] == 0]
    n_empty = len(empties)
    solutions: list = []

    def pick(depth, d):
        if var_order == "static":
            return empties[depth]
        best, best_n = -1, 99
        for i in empties:
            if grid[i] == 0:
                m = d[i] if use_fc else d[i] & ~(rows[ROW[i]] | cols[COL[i]] | boxes[BOX[i]])
                n = POPCNT[m]
                if n < best_n:
                    best, best_n = i, n
                    if n <= 1:
                        break
        return best

    def rec(depth, d):
        if depth == n_empty:
            solutions.append(grid[:])
            return len(solutions) >= max_solutions
        v = pick(depth, d)
        r, cc, b = ROW[v], COL[v], BOX[v]
        avail = d[v] if use_fc else d[v] & ~(rows[r] | cols[cc] | boxes[b])
        digits = DIGITS[avail]
        if rng is not None:
            digits = digits[:]
            rng.shuffle(digits)
        for dig in digits:
            bit = 1 << (dig - 1)
            c.assignments += 1
            if node_limit is not None and c.assignments > node_limit:
                raise _Limit
            grid[v] = dig
            rows[r] |= bit
            cols[cc] |= bit
            boxes[b] |= bit
            ok, stop = True, False
            if use_fc:
                nd = d[:]
                nd[v] = bit
                for p in PEERS[v]:
                    if grid[p] == 0 and nd[p] & bit:
                        nd[p] &= ~bit
                        c.fc_prunes += 1
                        if nd[p] == 0:
                            ok = False
                            break
                if ok:
                    stop = rec(depth + 1, nd)
            else:
                stop = rec(depth + 1, d)
            grid[v] = 0
            rows[r] &= ~bit
            cols[cc] &= ~bit
            boxes[b] &= ~bit
            if ok and stop:
                return True
            c.backtracks += 1
        return False

    try:
        rec(0, dom)
    except _Limit:
        return finish("limit", solutions, f"node limit of {node_limit} assignments reached")
    if solutions:
        return finish("solved", solutions, "solved")
    return finish("no_solution", [], "NO SOLUTION: search exhausted every assignment without finding a "
                                     "consistent grid (the givens are consistent but cannot be completed).")


def count_solutions(puzzle, limit: int = 2) -> int:
    return len(solve(puzzle, use_fc=True, use_ac3=False, var_order="mrv", max_solutions=limit).solutions)


def is_valid_solution(grid, puzzle=None) -> bool:
    if any(v not in range(1, 10) for v in grid):
        return False
    if any(sorted(grid[c] for c in unit) != list(range(1, 10)) for unit in UNITS):
        return False
    return puzzle is None or all(p == 0 or p == g for p, g in zip(puzzle, grid))
