from __future__ import annotations

from pathlib import Path

import numpy as np


def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


class MLP:
    def __init__(self, sizes=(784, 128, 9), seed: int = 0, l2: float = 1e-4):
        self.sizes, self.l2 = tuple(sizes), l2
        rng = np.random.default_rng(seed)
        self.W = [rng.normal(0, np.sqrt(2.0 / a), (a, b)).astype(np.float32) for a, b in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros(b, dtype=np.float32) for b in sizes[1:]]

    def _forward(self, X, keep=False):
        acts = [X]
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            z = acts[-1] @ W + b
            acts.append(z if i == len(self.W) - 1 else np.maximum(z, 0))
        return (acts[-1], acts) if keep else acts[-1]

    def logits(self, X: np.ndarray) -> np.ndarray:
        return self._forward(np.asarray(X, dtype=np.float32))

    def predict_proba(self, X: np.ndarray, T: float = 1.0) -> np.ndarray:
        return softmax(self.logits(X) / T)

    def fit(self, Xtr, ytr, Xva, yva, epochs=20, batch=128, lr=1e-3, seed=0, patience=4, verbose=True):
        rng = np.random.default_rng(seed)
        m = [np.zeros_like(p) for p in self.W + self.b]
        v = [np.zeros_like(p) for p in self.W + self.b]
        t, best, best_params, bad, hist = 0, np.inf, None, 0, []
        n = len(Xtr)
        for ep in range(epochs):
            perm = rng.permutation(n)
            for s in range(0, n, batch):
                idx = perm[s:s + batch]
                xb, yb = Xtr[idx], ytr[idx]
                out, acts = self._forward(xb, keep=True)
                g = softmax(out)
                g[np.arange(len(yb)), yb] -= 1.0
                g /= len(yb)
                grads_W, grads_b = [None] * len(self.W), [None] * len(self.b)
                for i in range(len(self.W) - 1, -1, -1):
                    grads_W[i] = acts[i].T @ g + self.l2 * self.W[i]
                    grads_b[i] = g.sum(axis=0)
                    if i > 0:
                        g = (g @ self.W[i].T) * (acts[i] > 0)
                t += 1
                params, grads = self.W + self.b, grads_W + grads_b
                for k, (p, gr) in enumerate(zip(params, grads)):
                    m[k] = 0.9 * m[k] + 0.1 * gr
                    v[k] = 0.999 * v[k] + 0.001 * gr * gr
                    p -= lr * (m[k] / (1 - 0.9 ** t)) / (np.sqrt(v[k] / (1 - 0.999 ** t)) + 1e-8)
            pv = softmax(self.logits(Xva))
            val_nll, val_acc = nll(pv, yva), float((pv.argmax(1) == yva).mean())
            hist.append({"epoch": ep + 1, "val_nll": val_nll, "val_acc": val_acc})
            if verbose:
                print(f"  epoch {ep + 1:2d}  val_nll={val_nll:.4f}  val_acc={val_acc:.4f}")
            if val_nll < best - 1e-4:
                best, bad = val_nll, 0
                best_params = [p.copy() for p in self.W + self.b]
            else:
                bad += 1
                if bad >= patience:
                    break
        if best_params is not None:
            k = len(self.W)
            self.W, self.b = best_params[:k], best_params[k:]
        return hist

    def save(self, path: Path, temperature: float = 1.0):
        arrs = {f"W{i}": w for i, w in enumerate(self.W)}
        arrs.update({f"b{i}": b for i, b in enumerate(self.b)})
        np.savez(path, sizes=np.array(self.sizes), temperature=np.array(temperature), **arrs)

    @classmethod
    def load(cls, path: Path):
        if not Path(path).exists():
            raise FileNotFoundError(f"{path} missing - run `python train_nn.py` first (about 20 s)")
        with np.load(path) as z:
            net = cls(tuple(int(s) for s in z["sizes"]))
            net.W = [z[f"W{i}"] for i in range(len(net.W))]
            net.b = [z[f"b{i}"] for i in range(len(net.b))]
            return net, float(z["temperature"])


def nll(probs: np.ndarray, y: np.ndarray) -> float:
    return float(-np.log(np.clip(probs[np.arange(len(y)), y], 1e-12, 1)).mean())


def ece(probs: np.ndarray, y: np.ndarray, n_bins: int = 15) -> float:
    conf, pred = probs.max(1), probs.argmax(1)
    acc = (pred == y).astype(float)
    edges = np.linspace(0, 1, n_bins + 1)
    err = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = (conf > lo) & (conf <= hi)
        if sel.any():
            err += sel.mean() * abs(acc[sel].mean() - conf[sel].mean())
    return float(err)


def reliability_bins(probs, y, n_bins=10):
    conf, acc = probs.max(1), (probs.argmax(1) == y).astype(float)
    edges = np.linspace(0, 1, n_bins + 1)
    rows = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = (conf > lo) & (conf <= hi)
        if sel.any():
            rows.append((conf[sel].mean(), acc[sel].mean(), int(sel.sum())))
    return rows


def confusion_matrix(y_true, y_pred, k=9) -> np.ndarray:
    cm = np.zeros((k, k), dtype=int)
    np.add.at(cm, (y_true, y_pred), 1)
    return cm


def fit_temperature(logits: np.ndarray, y: np.ndarray) -> float:
    f = lambda lt: nll(softmax(logits / np.exp(lt)), y)
    lo, hi, phi = -1.5, 2.0, (np.sqrt(5) - 1) / 2
    a, b = hi - phi * (hi - lo), lo + phi * (hi - lo)
    for _ in range(40):
        if f(a) < f(b):
            hi, b = b, a
            a = hi - phi * (hi - lo)
        else:
            lo, a = a, b
            b = lo + phi * (hi - lo)
    return float(np.exp((lo + hi) / 2))


def evaluate(model: MLP, X, y, T: float = 1.0) -> dict:
    p = model.predict_proba(X, T)
    return {"accuracy": float((p.argmax(1) == y).mean()), "nll": nll(p, y), "ece": ece(p, y)}
