from __future__ import annotations

import random
from dataclasses import dataclass, field

import numpy as np

from . import csp, data, search


@dataclass
class ReadResult:
    grid: list
    probs: np.ndarray
    blank: np.ndarray


@dataclass
class PipelineResult:
    status: str
    solution: list | None
    read_grid: list
    corrections: list
    cost: float
    ac3_conflict: bool
    search: search.SearchResult
    message: str
    least_confident: list = field(default_factory=list)

    def text(self) -> str:
        lines = [f"status: {self.status.upper()}   (AC-3 conflict in first reading: {self.ac3_conflict})"]
        if self.corrections:
            lines.append("correction log (cell, read digit -> new digit, cost):")
            lines += [f"  r{c['row']}c{c['col']}: {c['read']} -> {c['new']}   cost {c['cost']}" for c in self.corrections]
            lines.append(f"  total cost {self.cost:.4f}")
        lines.append(self.message)
        return "\n".join(lines)


def read_mosaic(mosaic: np.ndarray, model, T: float = 1.0) -> ReadResult:
    mosaic = np.asarray(mosaic)
    if mosaic.shape != (252, 252):
        raise ValueError(f"mosaic must be 252x252 pixels (9x9 cells of 28x28), got shape {mosaic.shape}")
    cells = data.split_mosaic(mosaic)
    blank = data.is_blank(cells)
    probs = model.predict_proba(cells, T)
    probs[blank] = 0.0
    grid = [0 if blank[i] else int(probs[i].argmax()) + 1 for i in range(81)]
    return ReadResult(grid, probs, blank)


def solve_read(read: ReadResult, mode: str = "nn", algo: str = "ucs", goal: str = "solvable",
               rng: random.Random | None = None, trace_limit: int = 0, random_tries: int = 300,
               **problem_kw) -> PipelineResult:
    if mode not in ("nn", "none", "random"):
        raise ValueError(f"mode must be 'nn', 'none' or 'random', got {mode!r}")
    conflict = csp.ac3_conflict(read.grid)
    prob = search.CorrectionProblem(read.grid, read.probs, goal=goal, **problem_kw)
    if mode == "none":
        res = search.no_correction(prob)
    elif mode == "random":
        res = search.random_search(prob, rng or random.Random(0), tries=random_tries)
    else:
        res = search.best_first(prob, algo, trace_limit=trace_limit)
    cost = res.cost
    if res.status == "solved":
        msg = f"solved with {len(res.corrections)} correction(s)"
    else:
        msg = res.message
    return PipelineResult(res.status, res.solution, read.grid, res.corrections, cost, conflict, res,
                          msg, prob.least_confident())


def solve_mosaic(mosaic, model, T=1.0, **kw) -> PipelineResult:
    return solve_read(read_mosaic(mosaic, model, T), **kw)


def format_grid(grid, marks=(), conf=None) -> str:
    out = []
    for r in range(9):
        row = []
        for c in range(9):
            i, v = r * 9 + c, grid[r * 9 + c]
            row.append((str(v) if v else ".") + ("*" if i in marks else " "))
            if c % 3 == 2 and c < 8:
                row.append("| ")
        out.append("".join(row).rstrip())
        if r % 3 == 2 and r < 8:
            out.append("-" * 25)
    return "\n".join(out)
