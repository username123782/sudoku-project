from __future__ import annotations

import json
import math
import random
import time

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from . import config as C
from . import csp, data, generator as G, integration as I, nn

LEVELS = [0, 1, 2, 3, 4]
CSP_CONFIGS = {"BT": (False, False), "BT+FC": (True, False), "BT+FC+AC-3": (True, True)}
SEARCH_METHODS = {
    "UCS": dict(algo="ucs"),
    "Greedy": dict(algo="greedy"),
    "A*": dict(algo="astar"),
    "A*+unique": dict(algo="astar", goal="unique"),
    "A*+unique (cap 4)": dict(algo="astar", goal="unique", max_corrections=4),
    "No correction": dict(mode="none"),
    "Random": dict(mode="random"),
}


def load_model():
    return nn.MLP.load(C.MODELS / "mlp.npz")


def seed_stats(df: pd.DataFrame, group: list, metrics: list) -> pd.DataFrame:
    per_seed = df.groupby(group + ["seed"])[metrics].mean().reset_index()
    agg = per_seed.groupby(group)[metrics].agg(["mean", "std"])
    agg.columns = [f"{m}_{s}" for m, s in agg.columns]
    return agg.reset_index()


def fmt(stats: pd.DataFrame, group: list, metrics: dict) -> pd.DataFrame:
    out = stats[group].copy()
    for m, nd in metrics.items():
        out[m] = [f"{a:.{nd}f} ± {0 if math.isnan(b) else b:.{nd}f}" for a, b in
                  zip(stats[f"{m}_mean"], stats[f"{m}_std"])]
    return out


def save_table(df: pd.DataFrame, name: str, raw: pd.DataFrame | None = None):
    C.TABLES.mkdir(parents=True, exist_ok=True)
    (raw if raw is not None else df).to_csv(C.TABLES / f"{name}.csv", index=False)
    (C.TABLES / f"{name}.md").write_text(df.to_markdown(index=False) + "\n", encoding="utf-8")


def classifier_report():
    m = json.loads((C.RESULTS / "classifier_metrics.json").read_text(encoding="utf-8"))
    rows = []
    for name, label in (("logreg", "Logistic regression"), ("mlp", "MLP 784-128-9")):
        r = m[name]
        rows.append({"model": label, "test accuracy": f"{r['test_calibrated']['accuracy']:.4f}",
                     "NLL (T-scaled)": f"{r['test_calibrated']['nll']:.4f}",
                     "ECE raw": f"{r['test_raw']['ece']:.4f}", "ECE T-scaled": f"{r['test_calibrated']['ece']:.4f}",
                     "T": f"{r['temperature']:.3f}"})
    save_table(pd.DataFrame(rows), "classifier")
    C.FIGS.mkdir(parents=True, exist_ok=True)
    cm = np.array(m["mlp"]["confusion_matrix"])
    fig, ax = plt.subplots(figsize=(5.2, 4.6))
    ax.imshow(np.log1p(cm), cmap="Blues")
    for i in range(9):
        for j in range(9):
            ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=7,
                    color="white" if cm[i, j] > cm.max() / 3 else "black")
    ax.set_xticks(range(9), range(1, 10))
    ax.set_yticks(range(9), range(1, 10))
    ax.set_xlabel("predicted digit")
    ax.set_ylabel("true digit")
    ax.set_title("MLP confusion matrix (test set, digits 1-9)")
    fig.tight_layout()
    fig.savefig(C.FIGS / "classifier_confusion.png", dpi=150)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(4.8, 4.4))
    ax.plot([0.5, 1], [0.5, 1], "k:", label="perfect")
    for key, name, st in (("reliability_raw", "MLP raw", "o-"), ("reliability_cal", "MLP T-scaled", "s--")):
        b = np.array(m["mlp"][key])
        ax.plot(b[:, 0], b[:, 1], st, label=name, ms=4)
    b = np.array(m["logreg"]["reliability_cal"])
    ax.plot(b[:, 0], b[:, 1], "^-.", label="LogReg T-scaled", ms=4)
    ax.set_xlim(0.45, 1.01)
    ax.set_ylim(0.45, 1.01)
    ax.set_xlabel("mean confidence")
    ax.set_ylabel("accuracy")
    ax.set_title("Reliability diagram (test set)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(C.FIGS / "classifier_reliability.png", dpi=150)
    plt.close(fig)


def hard_pool_report():
    d = data.load_processed(auto_prepare=True)
    model, T = load_model()
    pools = G.build_pools(d, model, T)
    y, p = d["y_test"], pools.probs
    mis = p.argmax(1) != y
    hard = sum(len(v) for v in pools.hard.values())
    info = {"test_images": int(len(y)), "misclassified": int(mis.sum()), "hard_pool_size": int(hard),
            "hard_per_digit": {k: int(len(v)) for k, v in pools.hard.items()},
            "clean_pool_size": int(sum(len(v) for v in pools.clean.values())),
            "misread_conf_median": float(np.median(p.max(1)[mis])),
            "share_of_misreads_with_conf_le_0.9": float((p.max(1)[mis] <= C.HARD_CONF_MAX).mean())}
    (C.RESULTS / "hard_pool.json").write_text(json.dumps(info, indent=1), encoding="utf-8")
    return info


def run_search_experiments(seeds, n_puzzles, givens: int = 30, log_path=None) -> pd.DataFrame:
    d = data.load_processed(auto_prepare=True)
    model, T = load_model()
    pools = G.build_pools(d, model, T)
    rows = []
    logf = open(log_path, "w", encoding="utf-8") if log_path else None
    for s in seeds:
        puzzles = G.generate_puzzle_set(givens, s, n_puzzles)
        for i, p in enumerate(puzzles):
            for m in LEVELS:
                inst = G.make_instance(p["puzzle"], m, pools, random.Random(f"inst-{s}-{i}-{m}"))
                mosaic = G.render_mosaic(inst["image_idx"], d["X_test"], s * 100000 + i * 10 + m)
                read = I.read_mosaic(mosaic, model, T)
                real_mis = sum(read.grid[c] != p["puzzle"][c] for c in range(81))
                assert real_mis == m, "generator must inject exactly m misreads"
                for name, kw in SEARCH_METHODS.items():
                    kw = dict(kw)
                    if kw.get("mode") == "random":
                        kw["rng"] = random.Random(f"rnd-{s}-{i}-{m}")
                    t0 = time.perf_counter()
                    r = I.solve_read(read, **kw)
                    el = time.perf_counter() - t0
                    c = r.search.counters
                    if logf and name in ("UCS", "A*+unique"):
                        logf.write(json.dumps({"seed": s, "puzzle": i, "misreads": m, "method": name, "status": r.status,
                                               "total_cost": None if r.status != "solved" else round(r.cost, 4),
                                               "corrections": r.corrections}) + "\n")
                    rows.append({"seed": s, "puzzle": i, "misreads": m, "actual_misreads": real_mis, "method": name,
                                 "solved": float(r.status == "solved"),
                                 "recovered": float(r.solution == p["solution"]),
                                 "expanded": c.expanded, "generated": c.generated, "csp_calls": c.csp_calls,
                                 "csp_assignments": c.csp.assignments, "csp_backtracks": c.csp.backtracks,
                                 "cost": r.cost if r.status == "solved" else np.nan,
                                 "n_corrections": len(r.corrections), "ms": el * 1000})
    if logf:
        logf.close()
    return pd.DataFrame(rows)


def optimality_check(df: pd.DataFrame) -> dict:
    w = df[df.method.isin(["UCS", "A*", "Greedy"])].pivot_table(index=["seed", "puzzle", "misreads"], columns="method",
                                                              values="cost")
    both = w.dropna(subset=["UCS", "A*"])
    g = w.dropna(subset=["UCS", "Greedy"])
    gm = g[g.UCS > 0]
    return {"instances_where_UCS_and_A*_both_solved": int(len(both)),
            "A*_cost_differs_from_UCS": int((abs(both["A*"] - both["UCS"]) > 1e-9).sum()),
            "greedy_cost_above_UCS": int((g.Greedy > g.UCS + 1e-9).sum()),
            "greedy_instances_compared": int(len(g)),
            "greedy_mean_cost_ratio_vs_UCS": float((gm.Greedy / gm.UCS).mean()) if len(gm) else float("nan")}


def summarize_search(df: pd.DataFrame):
    g = ["misreads", "method"]
    s1 = seed_stats(df[df.method.isin(["UCS", "Greedy", "A*", "A*+unique", "A*+unique (cap 4)"])], g,
                    ["recovered", "solved", "expanded", "generated", "csp_calls", "cost", "ms"])
    t1 = fmt(s1, g, {"recovered": 3, "solved": 3, "expanded": 1, "generated": 1, "csp_calls": 2, "cost": 3, "ms": 1})
    save_table(t1, "exp1_search", s1)
    s3 = seed_stats(df[df.method.isin(["UCS", "No correction", "Random"])], g,
                    ["recovered", "solved", "csp_calls", "expanded"])
    s3["method"] = s3["method"].replace({"UCS": "NN-guided (UCS)"})
    t3 = fmt(s3, g, {"recovered": 3, "solved": 3, "csp_calls": 1})
    save_table(t3, "exp3_nn_effect", s3)
    def line(ax, stats, methods, metric, labels=None, logy=False):
        for k, m in enumerate(methods):
            sub = stats[stats.method == m].sort_values("misreads")
            ax.errorbar(sub.misreads, sub[f"{metric}_mean"], yerr=sub[f"{metric}_std"].fillna(0), marker="osv^d"[k % 5],
                        capsize=3, label=(labels or {}).get(m, m))
        ax.set_xlabel("injected misreads")
        ax.set_xticks(LEVELS)
        if logy:
            ax.set_yscale("log")
        ax.grid(alpha=.3)
        ax.legend(fontsize=8)

    fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.8))
    line(ax[0], s1, ["UCS", "Greedy", "A*"], "expanded", logy=True)
    ax[0].set_ylabel("nodes expanded (log)")
    ax[0].set_title("Exp 1: search effort")
    line(ax[1], s1, ["UCS", "Greedy", "A*", "A*+unique", "A*+unique (cap 4)"], "recovered")
    ax[1].set_ylabel("exact-solution recovery rate")
    ax[1].set_ylim(-0.02, 1.02)
    ax[1].set_title("Exp 1: recovery (cap 3 corrections)")
    fig.tight_layout()
    fig.savefig(C.FIGS / "exp1_search.png", dpi=150)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(5, 3.8))
    line(ax, s3, ["NN-guided (UCS)", "No correction", "Random"], "recovered")
    ax.set_ylabel("exact-solution recovery rate")
    ax.set_ylim(-0.02, 1.02)
    ax.set_title("Exp 3: NN-guided vs none vs random")
    fig.tight_layout()
    fig.savefig(C.FIGS / "exp3_nn_effect.png", dpi=150)
    plt.close(fig)
    return t1, t3


def run_csp_experiments(seeds, n_puzzles, node_limit: int = 1_000_000, givens=(25, 30, 35)) -> pd.DataFrame:
    rows = []
    for g in givens:
        for s in seeds:
            for i, p in enumerate(G.generate_puzzle_set(g, s, n_puzzles)):
                for name, (fc, ac) in CSP_CONFIGS.items():
                    for order in ("static", "mrv"):
                        r = csp.solve(p["puzzle"], use_fc=fc, use_ac3=ac, var_order=order, node_limit=node_limit)
                        c = r.counters
                        rows.append({"givens": g, "seed": s, "puzzle": i, "config": name, "order": order,
                                     "solved": float(r.status == "solved"), "limit_hit": float(r.status == "limit"),
                                     "assignments": c.assignments, "backtracks": c.backtracks,
                                     "fc_prunes": c.fc_prunes, "ac3_prunes": c.ac3_prunes, "ms": r.elapsed * 1000})
    return pd.DataFrame(rows)


def summarize_csp(df: pd.DataFrame):
    g = ["order", "givens", "config"]
    metrics = ["assignments", "backtracks", "fc_prunes", "ac3_prunes", "ms", "solved", "limit_hit"]
    s = seed_stats(df, g, metrics)
    t = fmt(s, g, {"assignments": 0, "backtracks": 0, "fc_prunes": 0, "ac3_prunes": 0, "ms": 2, "solved": 3})
    save_table(t, "exp2_csp", s)
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8), sharey=False)
    for ax, order in zip(axes, ("static", "mrv")):
        sub = s[s.order == order]
        for k, cfg in enumerate(CSP_CONFIGS):
            q = sub[sub.config == cfg].sort_values("givens")
            ax.bar(np.arange(3) + (k - 1) * 0.27, q.assignments_mean, 0.25, yerr=q.assignments_std.fillna(0),
                   capsize=2, label=cfg)
        ax.set_xticks(range(3), [f"{x} givens" for x in sorted(df.givens.unique())])
        ax.set_yscale("log")
        ax.set_ylabel("assignments (log)")
        ax.set_title(f"Exp 2: {'static row-major' if order == 'static' else 'MRV'} variable order")
        ax.grid(alpha=.3, axis="y")
        ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(C.FIGS / "exp2_csp.png", dpi=150)
    plt.close(fig)
    return t
